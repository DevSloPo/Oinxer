# -*- coding: utf-8 -*-
"""Oinxer Web API —— 供浏览器端 (Pyodide) 调用的统一入口

只依赖纯 Python (luaparser / antlr4-runtime / multimethod),
不依赖 lupa, 因此可运行在浏览器内的 Pyodide 环境。
"""
import sys, os, re, random

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

from preprocess import preprocess
import oinxer_v13f as W

CORE_VERSION = "1.3.0"
DEFAULT_BANNER = "-- This file is protected by Luraph v1.3.0 special edition --"


def _join(lines):
    """拼接成单行, 并在 ')'/'end'/字面量 后紧跟 '(' 处补分号避免调用歧义"""
    parts = []
    for ln in lines:
        if parts:
            prev = parts[-1]
            if ln.startswith("(") and prev[-1] not in ";,=([{+-*/%^<>:.~#&|\"":
                parts[-1] = prev + ";"
        parts.append(ln)
    return " ".join(parts)


def flatten(code, banner=DEFAULT_BANNER, mode="full"):
    """把产物压成零换行的糊状体

    mode: full 整个文件压成一行 / head 只压头部 / none 不压
    """
    lines = [l.strip() for l in code.split("\n")]
    # 必须先剔除整行注释: banner 一旦被拼进单行, 后面的代码会全部被 "--" 吃掉
    lines = [l for l in lines if l and not l.startswith("--")]
    if mode == "none":
        return (banner + "\n" if banner else "") + code
    if mode == "head":
        cut = 0
        for i, l in enumerate(lines):
            if len(l) > 4096:
                cut = i
        head, tail = lines[:cut + 1], lines[cut + 1:]
        return (banner + "\n" if banner else "") + _join(head) + "\n" + "\n".join(tail) + "\n"
    return (banner + "\n" if banner else "") + _join(lines) + "\n"


def obfuscate(src, seed=None, spread=5, dead=0.15, runnable=True,
              banner=DEFAULT_BANNER, flatten_mode="full"):
    """返回 dict: code / meta / stats / leak"""
    if seed is None:
        seed = random.randrange(1, 2 ** 31 - 1)
    src_pp, n1, n2 = preprocess(src)
    meta = {}
    l0 = W.build(src_pp, seed=seed, spread=spread, dead=dead,
                 runnable=runnable, meta=meta)
    code = W.finalize(l0, banner=None, wrap=runnable)
    meta.update(continue_n=n1, compound_n=n2, seed=seed)
    if flatten_mode != "none":
        code = flatten(code, banner=None, mode=flatten_mode)
    out = ((banner + "\n") if banner else "") + code.strip() + "\n"

    # 明文泄漏自检
    leaks = set(re.findall(r'"([^"\\]{4,})"', out))
    strings = set(re.findall(r'"([^"\\]{4,})"', src_pp))
    hit = sorted([s for s in strings if s in leaks])

    keys = ("seed", "nproto", "l1_bytes", "ndead", "nflat_blocks",
            "nflat_insns", "boot", "l0_chunks", "continue_n", "compound_n")
    return {
        "code": out,
        "version": CORE_VERSION,
        "bytes": len(out.encode("utf-8")),
        "lines": out.count("\n"),
        "meta": {k: meta.get(k) for k in keys},
        "leak": {"total": len(strings), "leaked": len(hit), "sample": hit[:8]},
    }


def selftest():
    """核心自检: 编译并运行一小段脚本, 确认链路可用"""
    src = "local t = 0\nfor i = 1, 10 do\n  if i % 2 == 0 then t += i end\nend\nprint('SUM', t)\n"
    r = obfuscate(src, seed=12345, spread=3, dead=0.1, runnable=True)
    return {"ok": r["bytes"] > 1000 and r["leak"]["leaked"] == 0,
            "bytes": r["bytes"], "lines": r["lines"], "meta": r["meta"]}


if __name__ == "__main__":
    import json
    print(json.dumps(selftest(), ensure_ascii=False, indent=2))
