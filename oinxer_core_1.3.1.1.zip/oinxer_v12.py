#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Oinxer Obfuscator (Luraph Special Edition) v1.2.0

v1.1.0 暴露的缺陷 -> v1.2.0 对策
  1. base85 字符表明文 + 双 LCG seed 明文硬编码 (1674334961/1000714544) + a/m 明文
     -> L0 引导器: 字符表运行时由伪装载串哈希驱动 PRNG 打乱 ASCII 32..126 生成;
        XOR 密钥由密文引导头自身哈希派生(改一字节即全废); a 由 seed 派生, m 写成 2^31-1
  2. VM handler 明文闭包 (_CKiYMkE[213]=function() R[A]=R[B]+R[C] end 语义直读)
     -> 双层结构: 整个 VM 运行时(含 handler 表/常量解密算法/反 dump) 作为 L1
        加密成 base85 数据流, 运行时由 L0 解密后 load 执行。静态零 handler 语义
  3. 头部没糊在一起 / 行数过多 (v1.1.0 产物 527 行)
     -> 外层仅 L0 一段, 输出固定 2 行: banner + 单行代码

保留 v1.1.0 全部防护: 控制流平坦化 / 每 proto 独立置换表 / 运行时二次编号 /
5 种常量算法 + 诱饵池 + 反批量遍历 / 异常安全帧恢复
"""
import sys, os, random, string
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import oinxer_v11 as V
from build import b85_encode, mangle, LUA_KW, run_lua

HERE = os.path.dirname(os.path.abspath(__file__))
HDR = 32          # 引导头字节数 (不加密, 用于派生密钥)


def hash32(bs):
    """与运行时完全一致的哈希: h = h*131 + b (mod 2^31-1)"""
    h = 7
    for b in bs:
        h = (h * 131 + b) % 2147483647
    return h


def derive(boot):
    """复现 L0 的字符表生成过程, 返回 (alpha, mA, aA)"""
    s0 = hash32(boot.encode("latin-1"))
    mA = 2147483647
    aA = (s0 % 20000) * 2 + 16807
    # 必须排除 34(') 与 92(\): 否则 base85 数据写进 "..." 字面量会截断/转义出错
    p = [c for c in range(32, 127) if c != 34 and c != 92]
    for i in range(len(p), 1, -1):
        s0 = (s0 * aA) % mA
        j = (s0 % i) + 1
        p[i - 1], p[j - 1] = p[j - 1], p[i - 1]
    alpha = "".join(chr(c) for c in p[:85])
    return alpha, mA, aA


def xor_stream(data, seed, aA, mA):
    s = seed
    out = bytearray()
    for b in data:
        s = (s * aA) % mA
        out.append(b ^ (s % 256))
    return bytes(out)


# ============================================================
# L0 引导器模板
# ============================================================
BOOT_TPL = r'''
local §_by§, §_ch§, §_su§, §_le§ = string.byte, string.char, string.sub, string.len
local §_upk§ = table.unpack or unpack
local §_fl§ = math.floor
local §_cc§ = table.concat
local §_ty§ = type
local §_mA§ = §_fl§(2 ^ 31) - 1
local §_s0§ = 7
do
  local §_b§ = §BOOT§
  for §_i§ = 1, §_le§(§_b§) do §_s0§ = (§_s0§ * 131 + §_by§(§_b§, §_i§)) % §_mA§ end
end
local §_aA§ = (§_s0§ % 20000) * 2 + 16807
local §_A85§ = {}
do
  local §_p§, §_q§ = {}, 0
  for §_i§ = 32, 126 do
    if §_i§ ~= 34 and §_i§ ~= 92 then §_q§ = §_q§ + 1; §_p§[§_q§] = §_i§ end
  end
  for §_i§ = §_q§, 2, -1 do
    §_s0§ = (§_s0§ * §_aA§) % §_mA§
    local §_j§ = §_s0§ % §_i§ + 1
    §_p§[§_i§], §_p§[§_j§] = §_p§[§_j§], §_p§[§_i§]
  end
  for §_i§ = 1, 85 do §_A85§[§_p§[§_i§]] = §_i§ - 1 end
end
local function §_d85§(§_s§)
  local §_o§, §_n§, §_ac§, §_b2§ = {}, 0, 0, 0
  for §_i§ = 1, §_le§(§_s§) do
    local §_c§ = §_A85§[§_by§(§_s§, §_i§)]
    if §_c§ then
      §_ac§ = §_ac§ * 85 + §_c§
      §_b2§ = §_b2§ + 1
      if §_b2§ >= 5 then
        §_n§ = §_n§ + 1; §_o§[§_n§] = §_fl§(§_ac§ / 16777216) % 256
        §_n§ = §_n§ + 1; §_o§[§_n§] = §_fl§(§_ac§ / 65536) % 256
        §_n§ = §_n§ + 1; §_o§[§_n§] = §_fl§(§_ac§ / 256) % 256
        §_n§ = §_n§ + 1; §_o§[§_n§] = §_ac§ % 256
        §_ac§, §_b2§ = 0, 0
      end
    end
  end
  return §_o§
end
local function §_xr§(§_x§, §_y§)
  local §_r§, §_mm§ = 0, 1
  while §_x§ > 0 or §_y§ > 0 do
    local §_a§, §_b§ = §_x§ % 2, §_y§ % 2
    if §_a§ ~= §_b§ then §_r§ = §_r§ + §_mm§ end
    §_x§ = (§_x§ - §_a§) / 2
    §_y§ = (§_y§ - §_b§) / 2
    §_mm§ = §_mm§ * 2
  end
  return §_r§
end
local §_t§ = {}
§CHUNKS§
local §_raw§ = §_d85§(§_cc§(§_t§))
local §_ln§ = (§_raw§[1] or 0) + (§_raw§[2] or 0) * 256 + (§_raw§[3] or 0) * 65536 + (§_raw§[4] or 0) * 16777216
local §_ck§ = 7
for §_i§ = 1, §HDRLEN§ do §_ck§ = (§_ck§ * 131 + (§_raw§[§_i§] or 0)) % §_mA§ end
local §_s1§ = §_ck§
local §_src§ = {}
for §_i§ = §HDRLEN§ + 1, #§_raw§ do
  §_s1§ = (§_s1§ * §_aA§) % §_mA§
  §_src§[§_i§ - §HDRLEN§] = §_xr§(§_raw§[§_i§] or 0, §_s1§ % 256)
end
local §_o2§, §_i2§, §_c2§, §_nn§ = {}, 1, 0, §_ln§
while §_i2§ <= §_nn§ do
  local §_m2§ = §_nn§ - §_i2§ + 1
  if §_m2§ > 400 then §_m2§ = 400 end
  §_c2§ = §_c2§ + 1
  §_o2§[§_c2§] = §_ch§(§_upk§(§_src§, §_i2§, §_i2§ + §_m2§ - 1))
  §_i2§ = §_i2§ + §_m2§
end
local §_LD§ = load
if §_ty§(§_LD§) ~= "function" then §_LD§ = loadstring end
local §_f§, §_er§ = §_LD§(§_cc§(§_o2§))
if §_ty§(§_f§) ~= "function" then error(§_er§ or "bootstrap: load failed", 0) end
return §_f§()
'''

BOOTS = [
    "Oinxer runtime bootstrap :: integrity anchor :: do not modify",
    "generated payload container :: version stamp :: keep intact",
    "asset bundle descriptor :: checksum anchor :: internal use",
]


def build_l0(l1_src, boot, width, rng):
    alpha, mA, aA = derive(boot)
    lb = l1_src.encode("utf-8")
    ln = len(lb)
    hdr = bytes([ln & 0xFF, (ln >> 8) & 0xFF, (ln >> 16) & 0xFF, (ln >> 24) & 0xFF]) + \
          bytes(rng.randrange(1, 256) for _ in range(HDR - 4))
    ck = hash32(hdr)
    raw = hdr + xor_stream(lb, ck, aA, mA)
    data = b85_encode(raw, alpha)
    chunks = [data[i:i + width] for i in range(0, len(data), width)]
    body = "\n".join('§_t§[#§_t§+1]="%s"' % c for c in chunks)
    tpl = BOOT_TPL.replace("§CHUNKS§", body)
    tpl = tpl.replace("§BOOT§", '"%s"' % boot.replace('"', '\\"'))
    tpl = tpl.replace("§HDRLEN§", str(HDR))
    t = mangle(tpl, rng)
    # 单行化: 换行 -> 空格 (模板内无 -- 注释, 字符串字面量内无真实换行)
    t = " ".join(t.split("\n"))
    return t, len(chunks)


def build(src, seed=None, spread=5, dead=0.15, runnable=True,
          width=3000, boot=None, flatten=True, meta=None):
    rng = random.Random(seed)
    # L1: 完整 v1.1.0 VM 运行时 + payload
    tpl, data = V.build(src, seed=seed, spread=spread, dead=dead,
                        flatten=flatten, meta=meta)
    l1_code = tpl.replace("@DATA@", V.chunk_data(data, width))
    # 关键: L1 是被 load 的字符串 chunk, 必须显式 return, 否则顶层表达式的值被丢弃
    l1 = "return (function()\n%s\nend)()" % l1_code
    if runnable:
        l1 = l1 + "()"
    if boot is None:
        boot = BOOTS[rng.randrange(len(BOOTS))]
    l0, nchunk = build_l0(l1, boot, width, rng)
    if meta is not None:
        meta["boot"] = boot
        meta["l0_chunks"] = nchunk
        meta["l1_bytes"] = len(l1)
    return l0


BANNER = "This file is protected by Luraph v1.2.1 special edition"


def finalize(l0, banner=None, wrap=True):
    """v1.2.1:
       wrap=True  可直接运行版 —— 外层再包 (function() ... end)(), 粘进执行器即可跑
       wrap=False 纯代码块版   —— 裸语句。loadstring(game:HttpGet(url))() 一次调用
                                 即完整执行。
       旧版纯代码块是"L0 返回脚本函数但不调用"的形式: 作为 chunk 加载时表达式的值
       会被丢弃 (Lua 只在 chunk 为 return 表达式时才返回值), 结果 loadstring 后
       什么都不执行 —— 这正是"加载成功但功能全丢"的其中一个来源。
    """
    head = banner or BANNER
    if wrap:
        return "-- %s --\n(function() %s end)()" % (head, l0)
    return "-- %s --\n%s" % (head, l0)


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("src")
    ap.add_argument("-o", "--out", required=True)
    ap.add_argument("--seed", type=int, default=None)
    ap.add_argument("--spread", type=int, default=5)
    ap.add_argument("--dead", type=float, default=0.15)
    ap.add_argument("--width", type=int, default=3000)
    a = ap.parse_args()
    src = open(a.src, encoding="utf-8").read()
    meta = {}
    l0 = build(src, seed=a.seed, spread=a.spread, dead=a.dead, meta=meta)
    out = finalize(l0)
    open(a.out, "w", encoding="utf-8").write(out)
    print("OUT %s  bytes=%d  lines=%d  l1=%dB chunks=%d  nproto=%s flat=%s/%s" % (
        a.out, len(out.encode()), out.count("\n") + 1, meta.get("l1_bytes", 0),
        meta.get("l0_chunks", 0), meta.get("nproto"), meta.get("nflat_blocks"),
        meta.get("nflat_insns")))


# ============================================================
# 回归测试接口 (与 testsuite.py 兼容)
# ============================================================
_POS = None
_ADDR = None

def _norm(s):
    global _POS, _ADDR
    import re
    if _POS is None:
        # chunk 名也一样: L1 由 load(源码) 生成, chunkname 必然与原生不同
        _POS = re.compile(r'\[string "[^"]*"\](:\d+)?')
        _ADDR = re.compile(r'\b0x[0-9a-fA-F]+\b')
    return _ADDR.sub('0x?', _POS.sub('[string "?"]', s))


def check(src, name="test", seed=None, spread=5, dead=0.12, norm=True):
    from build import run_lua
    try:
        native = run_lua(src)
    except Exception as e:
        return False, "NATIVE FAIL %s" % str(e)[:200]
    try:
        obf = finalize(build(src, seed=seed, spread=spread, dead=dead))
        got = run_lua(obf)
    except Exception as e:
        return False, "VM RUN FAIL: %s" % str(e)[:300]
    if norm:
        native, got = _norm(native), _norm(got)
    if native == got:
        return True, ""
    return False, "DIFF\n--nat--\n%s\n--obf--\n%s" % (native[:400], got[:400])
