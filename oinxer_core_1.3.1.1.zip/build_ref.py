#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""序列化 proto -> Lua 表; 并与原生执行做等价性比对"""
import sys, os, random
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from compiler import Compiler, patch

# lupa 仅用于本地等价性验证; 浏览器端 (Pyodide) 没有 lupa,
# 因此做成可选导入, 否则整个核心在浏览器里会 ImportError。
try:
    from lupa import lua54
except Exception:  # pragma: no cover - Pyodide / 无 lupa 环境
    lua54 = None


def lstr(s):
    bs = s.encode("utf-8")
    out = ['"']
    for b in bs:
        if b == 0x5C:
            out.append("\\\\")
        elif b == 0x22:
            out.append('\\"')
        elif b == 0x0A:
            out.append("\\n")
        elif b == 0x0D:
            out.append("\\r")
        elif b == 0x09:
            out.append("\\t")
        elif 0x20 <= b < 0x7F:
            out.append(chr(b))
        else:
            out.append("\\%03d" % b)
    out.append('"')
    return "".join(out)


def lnum(v):
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, int):
        return str(v)
    if isinstance(v, float):
        if v == int(v) and abs(v) < 1e15:
            return "%d.0" % int(v)
        return repr(v)
    return "nil"


def ser_const(v):
    if isinstance(v, str):
        return lstr(v)
    return lnum(v)


# 常量索引字段 (0-based -> 1-based)
KFIELDS = {
    "LOADK": (2,), "GETGLOBAL": (2,), "SETGLOBAL": (2,),
    "GETFIELD": (3,), "SETFIELD": (2,),
}
PFIELDS = {"CLOSURE": (2,), "CLOSUREB": (2,)}
UFIELDS = {"GETUPVAL": (2,), "SETUPVAL": (2,)}


def ser_proto(P, ind=0):
    sp = "  " * ind
    L = []
    L.append(sp + "{")
    L.append(sp + "  nreg=%d," % max(P.maxreg, 2))
    L.append(sp + "  name=%s," % lstr(P.name))
    L.append(sp + "  nparam=%d," % P.nparam)
    # 常量
    if P.consts:
        ks = ",".join(ser_const(c) for c in P.consts)
        L.append(sp + "  k={%s}," % ks)
    else:
        L.append(sp + "  k={},")
    # upvalue 描述
    if P.upvals:
        us = []
        for (nm, kind, idx) in P.upvals:
            ix = idx + 1 if kind == "up" else idx
            us.append("{%s,%s,%d}" % (lstr(nm), lstr(kind), ix))
        L.append(sp + "  upv={%s}," % ",".join(us))
    else:
        L.append(sp + "  upv={},")
    # 代码
    L.append(sp + "  code={")
    for ins in P.code:
        op = ins[0]
        a, b, c = ins[1], ins[2], ins[3]
        vals = [a, b, c]
        for i in KFIELDS.get(op, ()):
            vals[i - 1] = vals[i - 1] + 1
        for i in PFIELDS.get(op, ()):
            vals[i - 1] = vals[i - 1] + 1
        for i in UFIELDS.get(op, ()):
            vals[i - 1] = vals[i - 1] + 1
        L.append(sp + '    {"%s",%d,%d,%d},' % (op, vals[0], vals[1], vals[2]))
    L.append(sp + "  },")
    # 子 proto
    if P.protos:
        L.append(sp + "  protos={")
        for s in P.protos:
            L.append(ser_proto(s, ind + 2) + ",")
        L.append(sp + "  },")
    L.append(sp + "}")
    return "\n".join(L)


def build_ref(src, vm_path=None):
    c = Compiler()
    P = c.compile(src)
    patch(P)
    vm = open(vm_path or os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                      "vm_ref.lua")).read()
    vm = vm.replace("local ROOT = _PHOENIX_ROOT",
                    "local ROOT = " + ser_proto(P))
    return vm


WRAP = """
local _out = {}
print = function(...)
  local t = {}
  for i = 1, select('#', ...) do t[i] = tostring((select(i, ...))) end
  _out[#_out+1] = table.concat(t, '\\t')
end
%s
return table.concat(_out, "\\n")
"""


def run_lua(src):
    L = lua54.LuaRuntime(unpack_returned_tuples=False)
    return L.execute(WRAP % src)


def check(src, name="test"):
    try:
        vm = build_ref(src)
    except Exception as e:
        return False, "COMPILE FAIL: %s: %s" % (type(e).__name__, e)
    # VM 版
    try:
        got = run_lua("local run = (function()\n%s\nend)()\nrun()" % vm)
    except Exception as e:
        return False, "VM RUN FAIL: %s" % str(e)[:400]
    # 原生版
    try:
        want = run_lua(src)
    except Exception as e:
        return False, "NATIVE RUN FAIL: %s" % str(e)[:400]
    import re as _re
    norm = lambda s: _re.sub(r'\]:\d+:', ']:LINE:', s)
    if norm(got) == norm(want):
        return True, "%d lines OK" % (got.count("\n") + 1 if got else 0)
    return False, "MISMATCH\n--- want ---\n%s\n--- got ---\n%s" % (want[:800], got[:800])


if __name__ == "__main__":
    f = sys.argv[1] if len(sys.argv) > 1 else "/data/workspace/obf/t1.lua"
    src = open(f).read()
    ok, msg = check(src)
    print("[%s] %s" % ("PASS" if ok else "FAIL", msg))
