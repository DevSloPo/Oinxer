#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Luraph 模式特性层 (v1.3.0)

从 Luraph v14.5.2 反混淆实战中提炼的招式, 移植到 Oinxer。

学到的 Luraph 招式 (按性价比):
  R1 三常量池 b/e/C    —— opcode 按类型从不同池取常量。逆向者要按 opcode 类别
                          分别破解三套池, 且各池算法族不同。拖库任一池拿到的
                          绝大多数是诱饵。(Luraph 主 proto 用 120 个 opcode,
                          常量散布在 b/e/C 三个池)
  R2 PC+1 跳转陷阱     —— Luraph 解释器末尾有 j=j+1, 跳转指令写入的目标实为
                          target-1。静态跟随会全盘偏一位。(这个坑在凤凰计划
                          第二阶段让我们整盘顺序错乱)
  R3 噪声 opcode       —— Luraph 有 op48/op168/op56/op11 等一堆 ";;;;;" 空操作,
                          真 opcode 淹没在噪声里
  R4 条件跳转多样化     —— Luraph 的条件跳转有 7+ 种形式, 各比较不同池:
                          T[P]==e / T[r] / not(T[r]<b) / not(C<T[r]) / T[R]==T[P] ...
  R5 数字常量算术化     —— Luraph 不直接存数字, 存 b[j]+e[j] / e[j]-C[j] 这类
                          两池相加形式, 单拖一个池拿不到真实值
  R6 调用后寄存器清零   —— Luraph 每次 CALL 后 for L in pairs(T) do if L>a then
                          T[L]=nil end, 栈上不留痕
"""
import sys, os, random
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from build import KFIELDS, ALL_OPS, DISPATCH

# opcode -> 常量池编号 (仿 Luraph 的 b/e/C 语义分工)
POOL_OF_OP = {
    "LOADK": 0,                       # 字面量池 (b)
    "GETGLOBAL": 1, "SETGLOBAL": 1,   # 全局名池 (e)
    "GETFIELD": 2, "SETFIELD": 2,     # 字段名池 (C)
}
DEFAULT_POOL = 0
POOL_VARS = ["§_KB§", "§_KE§", "§_KC§"]
NPOOL = 3

# 每池算法族 (互不重叠为主, 逆向者要分别逆三套)
POOL_ALGOS = [
    [0, 1],   # 池0: LCG流XOR / 递减加法链
    [2, 3],   # 池1: 双向XOR / 重排后再减
    [4, 0],   # 池2: 累积链 / LCG流XOR(不同盐)
]
# 每池盐值偏移 (同算法在不同池密钥不同)
POOL_SALT = [0, 7919, 104729]


def pool_of(op):
    return POOL_OF_OP.get(op, DEFAULT_POOL)


def pool_var(op):
    return POOL_VARS[pool_of(op)]


def const_usage(P):
    """返回每个池用到的常量索引集合 (0-based)。

    注意: 必须在"常量索引 +1(转 1-based)"之前调用, 因为这里读的是原始索引。
    """
    used = [set(), set(), set()]
    for ins in P.code:
        op = ins[0]
        for fi in KFIELDS.get(op, ()):
            idx = ins[fi]
            if isinstance(idx, int) and 0 <= idx < len(P.consts):
                used[pool_of(op)].add(idx)
    return used


def patch_dispatch_pools():
    """返回按 opcode 把 §_K§ 替换成对应池变量后的 DISPATCH 副本。"""
    out = {}
    for op, body in DISPATCH.items():
        out[op] = body.replace("§_K§", pool_var(op))
    return out


def gen_decoy(rng, kind):
    """诱饵常量: 与真实常量同形, 拖库时大量混入。"""
    if kind == 0:
        return rng.choice([
            rng.randrange(1, 10 ** rng.randrange(1, 7)),
            rng.randrange(1, 1000) / 100.0,
            -(rng.randrange(1, 10 ** 5)),
        ])
    if kind == 2:
        return rng.choice([True, False])
    n = rng.randrange(3, 24)
    pool = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_."
    return "".join(rng.choice(pool) for _ in range(n))
