#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Oinxer (Luraph Special Edition) v1.3.1.1 —— 压缩模式开关版

==========================================================
新增: 压缩模式 (compact) 可自由开关, 并支持按体积阈值自动启用
==========================================================
    compress  = "auto" (默认) | "on" | "off"
    threshold = 250 * 1024  (250KB, 可用 --threshold 改)

    压缩模式 ON  (体积优先, v1.3.1 链路)
        诱饵不落盘 / 置换表共享池 / 指令 varint / 紧凑常量头 / 大文件自适应
        目的: 大脚本产物压在 600~800KB, 根治"能加载但功能丢失 / 卡死"

    压缩模式 OFF (强度优先, v1.3.0 链路)
        诱饵全落盘 / 每 proto 独立置换表 / 定长指令 / 完整常量头 / 无自适应
        目的: 小脚本拿到最高强度。大脚本会因体积过大而失效,
              故 auto 模式下会被阈值自动切到压缩模式。

    自动判据: 输入源码 UTF-8 字节数 >= threshold  -> 启用压缩
              另: 源码虽小但编译后指令规模过大 (n_insn >= max_insns)
                  也自动启用, 避免小源码编译出大产物。

L1 (内层) = 三常量池 b/e/C + 空操作 opcode 群 + 平坦化 + 每 proto 置换
            + 运行时二次编号
L0 (外层) = 运行时生成 base85 字符表 + 密钥由密文引导头自身哈希派生,
            整个 L1 运行时(含 handler 语义/常量解密算法) 加密成 base85 数据流,
            静态看不到任何 opcode 语义

输出固定 2 行: 首行英文 banner, 第二行全部代码糊在一起
"""
import sys, os, random
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import oinxer_v12 as V12
import oinxer_v13 as V13
import oinxer_v131 as V131
from oinxer_v12 import build_l0, BOOTS, hash32

BANNER = "This file is protected by Luraph v1.3.1.1 special edition"

COMPRESS_THRESHOLD = 250 * 1024      # 250KB 自动启用压缩模式的阈值
MAX_INSNS = 45000                    # 指令规模阈值(源码小但编译后很大时兜底)


# ---------------- 压缩模式决策 ----------------
def resolve_compress(compress, src_bytes, n_insn=None, threshold=None,
                     max_insns=None):
    """返回 (compact: bool, reason: str)

    compress: "auto" | "on" | "off" | True | False | None
    """
    if threshold is None:
        threshold = COMPRESS_THRESHOLD
    if max_insns is None:
        max_insns = MAX_INSNS

    if compress is None:
        compress = "auto"
    if compress is True:
        compress = "on"
    if compress is False:
        compress = "off"
    compress = str(compress).lower().strip()
    if compress in ("1", "yes", "y", "true", "on", "force"):
        return True, "forced-on"
    if compress in ("0", "no", "n", "false", "off", "none"):
        return False, "forced-off"

    # ---- auto ----
    kb = threshold / 1024.0
    if src_bytes >= threshold:
        return True, "src %.1fKB >= %.0fKB" % (src_bytes / 1024.0, kb)
    if n_insn is not None and n_insn >= max_insns:
        return True, "insns %d >= %d" % (n_insn, max_insns)
    return False, "src %.1fKB < %.0fKB" % (src_bytes / 1024.0, kb)


def _estimate_insns(src):
    """编译一次估算指令规模 (用于 auto 判据的兜底)。

    失败时返回 None, 不影响主流程。
    """
    try:
        from compiler import Compiler, all_protos
        P = Compiler().compile(src)
        return sum(len(p.code) for p in all_protos(P))
    except Exception:
        return None


def build(src, seed=None, spread=5, dead=0.15, runnable=True,
          width=3000, boot=None, flatten=True, meta=None, lz=False,
          compress="auto", threshold=None, max_insns=None, estimate=True):
    """构建混淆产物。

    compress:
        "auto"  按 threshold(默认250KB) / max_insns 自动决定是否启用压缩模式
        "on"    强制压缩模式 (体积优先)
        "off"   强制完整模式 (强度优先)
    """
    rng = random.Random(seed)
    src_bytes = len(src.encode("utf-8"))

    n_insn = _estimate_insns(src) if (estimate and str(compress).lower() == "auto") else None
    compact, reason = resolve_compress(compress, src_bytes, n_insn,
                                       threshold, max_insns)
    if meta is not None:
        meta["src_bytes"] = src_bytes
        meta["n_insn_est"] = n_insn
        meta["compress"] = "on" if compact else "off"
        meta["compress_reason"] = reason

    if compact:
        # ---- 压缩模式 (v1.3.1 链路) ----
        tpl, data = V131.build(src, seed=seed, spread=spread, dead=dead,
                               flatten=flatten, meta=meta, lz=lz)
    else:
        # ---- 完整模式 (v1.3.0 链路) ----
        tpl, data = V13.build(src, seed=seed, spread=spread, dead=dead,
                              flatten=flatten, meta=meta)
    if meta is not None:
        meta["payload_bytes"] = meta.get("payload_bytes") or 0

    l1_code = tpl.replace("@DATA@", V13.chunk_data(data, width))
    l1 = "return (function()\n%s\nend)()" % l1_code
    if runnable:
        l1 = l1 + "()"
    if boot is None:
        boot = BOOTS[rng.randrange(len(BOOTS))]
    l0, nchunk = build_l0(l1, boot, width, rng)
    if meta is not None:
        meta["boot"] = boot
        meta["l0_chunks"] = nchunk
        meta["l1_bytes"] = len(l1)
    return l0


def finalize(l0, banner=None, wrap=True):
    head = banner or BANNER
    if wrap:
        return "-- %s --\n(function() %s end)()" % (head, l0)
    return "-- %s --\n%s" % (head, l0)


def build_file(src, out, seed=None, spread=5, dead=0.15, runnable=True,
               lz=False, compress="auto", threshold=None):
    meta = {}
    l0 = build(src, seed=seed, spread=spread, dead=dead,
               runnable=runnable, meta=meta, lz=lz,
               compress=compress, threshold=threshold)
    out_txt = finalize(l0, wrap=runnable)
    open(out, "w", encoding="utf-8").write(out_txt)
    return out_txt, meta


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser(
        description="Oinxer v1.3.1.1 —— 压缩模式可开关")
    ap.add_argument("src")
    ap.add_argument("-o", "--out", required=True)
    ap.add_argument("--seed", type=int, default=None)
    ap.add_argument("--spread", type=int, default=5)
    ap.add_argument("--dead", type=float, default=0.15)
    ap.add_argument("--pure", action="store_true",
                    help="纯代码块版(供 loadstring/远程加载)")
    ap.add_argument("--compress", default="auto", choices=["auto", "on", "off"],
                    help="压缩模式: auto=按阈值自动(默认) / on=强制开 / off=强制关")
    ap.add_argument("--threshold", type=int, default=250,
                    help="auto 模式阈值, 单位 KB (默认 250)")
    ap.add_argument("--lz", action="store_true", help="额外启用 payload zlib 压缩")
    a = ap.parse_args()
    src = open(a.src, encoding="utf-8").read()
    txt, meta = build_file(src, a.out, seed=a.seed, spread=a.spread,
                           dead=a.dead, runnable=not a.pure,
                           compress=a.compress,
                           threshold=a.threshold * 1024, lz=a.lz)
    print("OUT %s bytes=%d lines=%d l1=%dB chunks=%d nproto=%s flat=%s/%s" % (
        a.out, len(txt.encode()), txt.count("\n") + 1, meta.get("l1_bytes", 0),
        meta.get("l0_chunks", 0), meta.get("nproto"),
        meta.get("nflat_blocks"), meta.get("nflat_insns")))
    print("compress=%s (%s) src=%.1fKB" % (
        meta.get("compress"), meta.get("compress_reason"),
        meta.get("src_bytes", 0) / 1024.0))


# ============================================================
# 回归测试接口 (与 testsuite.py 兼容)
# ============================================================
_POS = None
_ADDR = None


def _norm(s):
    global _POS, _ADDR
    import re
    if _POS is None:
        _POS = re.compile(r'(\[string "[^"]*"\]|\[string "<python>"\])(:\d+)?')
        _ADDR = re.compile(r'\b0x[0-9a-fA-F]+\b')
    return _ADDR.sub('0x?', _POS.sub('[string "?"]', s))


def check(src, name="test", seed=None, spread=5, dead=0.12, norm=True,
          compress="auto", **kw):
    from build import run_lua
    try:
        native = run_lua(src)
    except Exception as e:
        return False, "NATIVE FAIL %s" % str(e)[:200]
    try:
        l0 = build(src, seed=seed, spread=spread, dead=dead,
                   runnable=True, flatten=kw.get("flatten", True),
                   compress=compress)
        got = run_lua(finalize(l0))
    except Exception as e:
        return False, "VM RUN FAIL: %s" % str(e)[:300]
    if norm:
        native, got = _norm(native), _norm(got)
    if native == got:
        return True, ""
    return False, "DIFF\n--nat--\n%s\n--obf--\n%s" % (native[:500], got[:500])
