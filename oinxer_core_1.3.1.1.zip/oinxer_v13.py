#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Oinxer Obfuscator (Luraph Special Edition) v1.3.0

从 Luraph v14.5.2 反混淆实战中反向学到的招式 (详见 luraph_mode.py):
  R1 三常量池 b/e/C  —— opcode 按类型从不同池取常量; 各池算法族不同; 未使用的
                        槽位全部填充诱饵。拖库任一池拿到的大部分是假值。
                        (Luraph 主 proto 用 120 个 opcode, 常量散布 b/e/C 三池)
  R3 空操作 opcode 群 —— 仿 Luraph op48/op168/op56/op11: 8 种不同编号的空操作
                        指令混进指令流, 静态反汇编看到大量"像真的"的指令
  R5 数字算术化      —— (后续)

保留 v1.2.x 全部防护: 双层 L0/L1 / 每 proto 独立置换 / 运行时二次编号 /
控制流平坦化 / 反 hook / 反 dump
"""
import sys, os, random, string
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import oinxer_v11 as V
from oinxer_v11 import ALGOS, u16, u32, lua_str, chunk_data
from build import (run_lua, fmt_num, DISPATCH, ALL_OPS, KFIELDS, PFIELDS, UFIELDS,
                   inject_dead, xor_all, b85_encode, strip_tpl_comments,
                   LUA_KW, mangle)
from compiler import Compiler, patch, all_protos, Label
from flatten import flatten_all
from luraph_mode import (POOL_VARS, POOL_ALGOS, NPOOL, const_usage,
                         patch_dispatch_pools, gen_decoy, pool_of)

HERE = os.path.dirname(os.path.abspath(__file__))

# ---- R3: 空操作 opcode 群 (仿 Luraph op48/op168/op56/op11) ----
NOISE_OPS = ["DEAD%d" % i for i in range(8)]
ALL_OPS13 = ALL_OPS + NOISE_OPS
# 每种空操作的"伪装形态": 读操作数但不产生任何效果
NOISE_BODIES = [
    "do end",
    "local §_z§ = §_A§",
    "local §_z§ = §_B§",
    "local §_z§ = §_C§",
    "local §_z§ = (§_A§ + 0)",
    "local §_z§ = #§_R§",
    "local §_z§ = (§_B§ ~= nil)",
    "if §_A§ == 2147483647 then §_A§ = §_A§ end",
]
DISPATCH13 = patch_dispatch_pools()
for i, op in enumerate(NOISE_OPS):
    DISPATCH13[op] = NOISE_BODIES[i % len(NOISE_BODIES)]


def make_opmap13(rng, spread=1):
    slots = list(range(1, 256))
    rng.shuffle(slots)
    opmap, i = {}, 0
    for op in ALL_OPS13:
        opmap[op] = slots[i]
        i += 1
    extra = {}
    if spread > 1:
        hot = ["MOVE", "LOADK", "GETFIELD", "GETGLOBAL", "SETTABLE", "GETTABLE",
               "SETFIELD", "ADD", "EQ", "JMPIFNOT"]
        for op in hot:
            for _ in range(spread - 1):
                if i >= len(slots):
                    break
                extra.setdefault(op, []).append(slots[i])
                i += 1
    return opmap, extra


def inject_dead_v13(root, rng, density, noise_ops):
    """插入空操作指令。必须在 patch() 之前, 并同步修正 Label.pos。"""
    n = 0
    for P in all_protos(root):
        out, mapping = [], {}
        for idx, ins in enumerate(P.code):
            mapping[idx] = len(out)
            out.append(ins)
            if rng.random() < density:
                op = noise_ops[rng.randrange(len(noise_ops))] if noise_ops else "DEAD"
                out.append([op, rng.randrange(0, 256), rng.randrange(0, 256),
                            rng.randrange(0, 256)])
                n += 1
        mapping[len(P.code)] = len(out)
        labels = {}
        for ins in P.code:
            for idx in range(1, 4):
                if isinstance(ins[idx], Label):
                    labels[id(ins[idx])] = (ins[idx], ins[idx].pos)
        for lb, oldpos in labels.values():
            lb.pos = mapping.get(oldpos, oldpos)
        P.code = out
    return n


# ============================================================
# R1: 三常量池序列化
# ============================================================
def ser_const_pool_v13(P, seed2, cid_counter, rng):
    nk = len(P.consts)
    used = getattr(P, "_pool_used", None) or const_usage(P)
    out = bytearray()
    out += u16(nk)
    for pi in range(NPOOL):
        algos = POOL_ALGOS[pi]
        # 池号参与密钥派生, 必须与 VM 侧 §_pool§(enc, pi) 的
        #   sd = (SEED2 + (cid + pi*104729) * 104729) % (2^31-1)
        # 完全一致。等价写法: 给该池换一个派生种子
        #   sd = (SEED2 + pi*104729*104729 + cid*104729) % (2^31-1)
        sp = (seed2 + pi * 104729 * 104729) % 2147483647
        for i in range(nk):
            cid = next(cid_counter)
            c = P.consts[i] if i in used[pi] else gen_decoy(rng, rng.choice([1, 1, 1, 0, 2]))
            if isinstance(c, bool):
                out += bytes([2]) + u32(cid) + bytes([rng.randrange(5)]) + bytes([1 if c else 0])
                continue
            if isinstance(c, (int, float)):
                s, ty = fmt_num(c), 0
            else:
                s, ty = (c if isinstance(c, str) else str(c)), 1
            raw = s.encode("utf-8")
            ai = algos[rng.randrange(len(algos))]
            e = ALGOS[ai](raw, sp, cid)
            out += bytes([ty]) + u32(cid) + bytes([ai]) + u32(len(e)) + e
    return bytes(out)


def ser_proto_v13(p, idx_of, seed2, cid_counter, perm_idx, rng):
    out = bytearray()
    out += u16(max(p.maxreg, 2))
    out += u16(p.nparam)
    out += u16(perm_idx)
    out += ser_const_pool_v13(p, seed2, cid_counter, rng)
    out += u16(len(p.upvals))
    for (nm, kind, ix) in p.upvals:
        out += bytes([1 if kind == "reg" else 0]) + u16(ix + 1 if kind == "up" else ix)
    out += u32(len(p.code))
    for ins in p.code:
        out += bytes([ins[0]]) + u16(ins[1]) + u16(ins[2]) + u16(ins[3])
    jt = getattr(p, "jt", None) or {}
    out += u32(len(jt))
    for s_, pc_ in jt.items():
        out += u32(s_) + u32(pc_)
    out += u16(len(p.protos))
    for s in p.protos:
        out += u32(idx_of[id(s)])
    return bytes(out)


# ============================================================
def _fix13(body, op, opmap):
    b = body
    if op in ("RETURN", "RETURNM"):
        b = b.replace("return §_o§ end", "§_RES§ = §_o§ end")
    if op in ("VARARG", "VARARGM"):
        b = b.replace("§_args§", "§_ARGS§").replace("§_na§", "§_NA§")
    if op == "CALL":
        b = b.replace("(§_o§ == §OC_CALLM§) and §_nr§ or (§_C§ - 1)", "(§_C§ - 1)")
    if op == "CALLM":
        b = DISPATCH13["CALL"].replace("(§_o§ == §OC_CALLM§) and §_nr§ or (§_C§ - 1)", "§_nr§")
        b = b.replace("§_args§", "§_ARGS§").replace("§_na§", "§_NA§")
    return b


def gen_handlers13(opmap, extra, rng):
    items = []
    for op, num in opmap.items():
        body = DISPATCH13.get(op)
        if body is None:
            # CALLM 与 CALL 共用实现, 但必须独立生成一份,
            # 否则方法调用(obj:m()) 生成的多返回值调用会被静默跳过
            if op == "CALLM":
                body = DISPATCH13["CALL"]
            else:
                continue
        items.append((num, _fix13(body, op, opmap)))
    for op, nums in (extra or {}).items():
        for n in nums:
            items.append((n, _fix13(DISPATCH13[op], op, opmap)))
    rng.shuffle(items)
    return "\n".join("§_H§[%d] = function() %s end" % (n, b) for n, b in items)


def build(src, seed=None, spread=1, dead=0.0, bulklm=512, meta=None, trace=False,
          flatten=True, min_blocks=3):
    rng = random.Random(seed)
    c = Compiler()
    P = c.compile(src)

    ndead = inject_dead_v13(P, rng, dead, NOISE_OPS)
    patch(P)

    nflat_b = nflat_i = 0
    if flatten:
        nflat_b, nflat_i = flatten_all(P, rng, min_blocks)

    protos = all_protos(P)
    order = []
    def walk(p):
        order.append(p)
        for s in p.protos:
            walk(s)
    walk(P)
    idx_of = {id(p): i for i, p in enumerate(order)}

    # R1: 索引 +1 之前先算各池用到的索引 (0-based)
    for p in protos:
        p._pool_used = const_usage(p)

    opmap, extra = make_opmap13(rng, spread)
    seed1 = rng.randrange(1, 2147483646)
    seed2 = rng.randrange(1, 2147483646)

    perms, p2x = [], []
    for p in order:
        perm = [0] * 256
        slots = list(range(256))
        rng.shuffle(slots)
        m = {}
        for op in ALL_OPS13:
            x = slots.pop()
            perm[x] = opmap[op]
            m[op] = x
        perms.append(perm)
        p2x.append(m)

    for p in protos:
        for ins in p.code:
            for fi in KFIELDS.get(ins[0], ()):
                ins[fi] += 1
            for fi in PFIELDS.get(ins[0], ()):
                ins[fi] += 1
            for fi in UFIELDS.get(ins[0], ()):
                ins[fi] += 1

    cid_counter = iter(range(1, 10 ** 9))
    body = bytearray()
    for pi, p in enumerate(order):
        old = p.code
        p.code = [[p2x[pi][ins[0]], ins[1], ins[2], ins[3]] for ins in old]
        try:
            body += ser_proto_v13(p, idx_of, seed2, cid_counter, pi + 1, rng)
        finally:
            p.code = old

    n = len(order)
    payload = (bytes([2]) + u16(n) + bytes(b for perm in perms for b in perm)
               + u16(n) + bytes(body))

    enc = xor_all(payload, seed1)
    alpha = list(string.digits + string.ascii_letters + "!#$%&()*+-;<=>?@^_`{|}~")
    rng.shuffle(alpha)
    alpha = "".join(alpha[:85])
    data = b85_encode(enc, alpha)

    strs = []
    for p in protos:
        for k in p.consts:
            if isinstance(k, str) and 2 < len(k) < 64:
                strs.append(k)
    rng.shuffle(strs)
    decoy = strs[:24] or ["nil"]
    dl = ", ".join(lua_str(s, full=True) for s in decoy)

    tpl = open(os.path.join(HERE, "runtime_v13.tpl.lua")).read()
    tpl = strip_tpl_comments(tpl)
    tpl = tpl.replace("§ALPHA§", '"%s"' % alpha)
    tpl = tpl.replace("§SEED1§", str(seed1))
    tpl = tpl.replace("§SEED2§", str(seed2))
    tpl = tpl.replace("§RKBASE§", str(rng.randrange(1, 2147483646)))
    tpl = tpl.replace("§BULKLIM§", str(bulklm))
    tpl = tpl.replace("§DECOY§", "{%s}" % dl)
    tpl = tpl.replace("§HANDLERS§", gen_handlers13(opmap, extra, rng))
    tpl = tpl.replace("§TRACE§", "")
    tpl = tpl.replace("§DATA§", "@DATA@")
    if meta is not None:
        meta.update(dict(opmap=opmap, extra=extra, p2x=p2x, seed2=seed2, ndead=ndead,
                         nproto=len(order), perms=perms,
                         nflat_blocks=nflat_b, nflat_insns=nflat_i,
                         nnoise_op=len(NOISE_OPS), npool=NPOOL))
    tpl = mangle(tpl, rng)
    return tpl, data


# ============================================================
# 回归测试接口
# ============================================================
_POS = None
_ADDR = None

def _norm(s):
    global _POS, _ADDR
    import re
    if _POS is None:
        _POS = re.compile(r'\[string "[^"]*"\](:\d+)?')
        _ADDR = re.compile(r'\b0x[0-9a-fA-F]+\b')
    return _ADDR.sub('0x?', _POS.sub('[string "?"]', s))


def check(src, name="test", seed=None, spread=5, dead=0.12, norm=True, flatten=True):
    try:
        native = run_lua(src)
    except Exception as e:
        return False, "NATIVE FAIL %s" % str(e)[:200]
    try:
        tpl, data = build(src, seed=seed, spread=spread, dead=dead, flatten=flatten)
        code = tpl.replace("@DATA@", chunk_data(data, 3000))
        got = run_lua("return (function()\n%s\nend)()()" % code)
    except Exception as e:
        return False, "VM RUN FAIL: %s" % str(e)[:300]
    if norm:
        native, got = _norm(native), _norm(got)
    if native == got:
        return True, ""
    return False, "DIFF\n--nat--\n%s\n--obf--\n%s" % (native[:500], got[:500])


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("src")
    ap.add_argument("-o", "--out", required=True)
    ap.add_argument("--seed", type=int, default=None)
    ap.add_argument("--spread", type=int, default=5)
    ap.add_argument("--dead", type=float, default=0.15)
    a = ap.parse_args()
    src = open(a.src, encoding="utf-8").read()
    meta = {}
    tpl, data = build(src, seed=a.seed, spread=a.spread, dead=a.dead, meta=meta)
    code = tpl.replace("@DATA@", chunk_data(data, 3000))
    out = ("-- This file is protected by Luraph v1.3.0 special edition --\n"
           "(function() return (function()\n%s\nend)()() end)()" % code)
    open(a.out, "w", encoding="utf-8").write(out)
    print("OUT %s bytes=%d nproto=%s dead=%s flat=%s/%s" % (
        a.out, len(out.encode()), meta.get("nproto"), meta.get("ndead"),
        meta.get("nflat_blocks"), meta.get("nflat_insns")))
