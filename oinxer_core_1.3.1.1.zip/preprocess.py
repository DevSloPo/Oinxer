#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Luau -> Lua5.3 预处理
1) continue  ->  goto + label (Lua5.3/5.4 合法, 语义等价)
2) 复合赋值 += -= *= /= %= ..=  ->  展开
输出可被 luaparser 解析的源码
"""
import re

KEYWORDS = {"for", "while", "repeat", "if", "elseif", "else", "do", "function",
            "then", "end", "until", "continue", "local", "return", "break"}


def mask_string_comment(s):
    """返回 mask 列表: True 表示该字符位于字符串/注释内(需跳过)"""
    n = len(s)
    mask = bytearray(n)
    i = 0
    while i < n:
        c = s[i]
        # 注释
        if c == "-" and i + 1 < n and s[i + 1] == "-":
            j = i + 2
            # 长注释 --[[ 或 --[==[
            m = re.match(r"--\[(=*)\[", s[i:])
            if m:
                eq = m.group(1)
                close = "]" + eq + "]"
                k = s.find(close, i + m.end())
                j = (k + len(close)) if k >= 0 else n
            else:
                k = s.find("\n", i)
                j = (k + 1) if k >= 0 else n
            for x in range(i, min(j, n)):
                mask[x] = 1
            i = j
            continue
        # 长字符串
        m = re.match(r"\[(=*)\[", s[i:])
        if m:
            eq = m.group(1)
            close = "]" + eq + "]"
            k = s.find(close, i + m.end())
            j = (k + len(close)) if k >= 0 else n
            for x in range(i, min(j, n)):
                mask[x] = 1
            i = j
            continue
        # 引号字符串
        if c in "\"'":
            j = i + 1
            while j < n:
                if s[j] == "\\":
                    j += 2
                    continue
                if s[j] == c:
                    j += 1
                    break
                if s[j] == "\n":
                    break
                j += 1
            for x in range(i, min(j, n)):
                mask[x] = 1
            i = j
            continue
        i += 1
    return mask


IDENT = re.compile(r"[A-Za-z_][A-Za-z0-9_]*")


def scan(s, mask):
    """产出 token 列表 [(kind, start, end)]"""
    toks = []
    for m in IDENT.finditer(s):
        a, b = m.start(), m.end()
        if mask[a]:
            continue
        w = m.group()
        if w not in KEYWORDS:
            continue
        # 词边界检查(前后非 ident/数字/点)
        if a > 0 and (src[a - 1].isalnum() or src[a - 1] in "_."):
            continue
        if b < len(src) and (src[b].isalnum() or src[b] in "_."):
            continue
        toks.append((w, a, b))
    toks.sort(key=lambda t: t[1])
    return toks


def convert_continue(src):
    """continue -> __PHX_CONTINUE__()  (语义由 compiler 的 cont 栈实现)"""
    mask = mask_string_comment(src)
    edits = []
    n = 0
    for m in IDENT.finditer(src):
        a, b = m.start(), m.end()
        if m.group() != "continue":
            continue
        if mask[a]:
            continue
        if a > 0 and (src[a - 1].isalnum() or src[a - 1] in "_."):
            continue
        if b < len(src) and (src[b].isalnum() or src[b] in "_."):
            continue
        n += 1
        edits.append((a, b, "__PHX_CONTINUE__()"))
    out = src
    for (a, b, t) in sorted(edits, key=lambda x: -x[0]):
        out = out[:a] + t + out[b:]
    return out, n


COMPOUND = re.compile(
    r"([A-Za-z_][A-Za-z0-9_]*(?:\s*\.\s*[A-Za-z_][A-Za-z0-9_]*|\s*\[[^\]]*\])*)"
    r"\s*([-+*/%]|)\s*=(?!=)")


TOKPAT = re.compile(r"\s+|\d+(?:\.\d*)?(?:[eE][-+]?\d+)?|[A-Za-z_][A-Za-z0-9_]*|.")

def scan_expr_end(src, start, mask):
    """从 start 扫描表达式结束位置 (括号平衡, 遇到'值 值'或行尾/关键词即止)"""
    i = start
    n = len(src)
    prev = None          # 上一个有效 token 类型
    depth = 0
    last_end = start
    while i < n:
        m = TOKPAT.match(src, i)
        if not m:
            break
        t = m.group()
        i2 = m.end()
        if t.isspace():
            if "\n" in t:
                return last_end
            i = i2
            continue
        if t in "([{":
            depth += 1
            prev = "p"
            i = i2
            last_end = i2
            continue
        if t in ")]}":
            depth -= 1
            if depth < 0:
                return last_end
            prev = "v"
            i = i2
            last_end = i2
            continue
        if t == ";":
            return last_end
        if t == "," and depth == 0:
            return last_end
        if t[0].isdigit():
            if prev == "v":
                return last_end
            prev = "v"
            i = i2
            last_end = i2
            continue
        if t[0].isalpha() or t[0] == "_":
            if t in ("end", "until", "else", "elseif", "do", "then", "return",
                     "break", "local", "for", "while", "if", "function", "and",
                     "or", "not", "in"):
                if t in ("end", "until", "else", "elseif", "do", "then", "return",
                         "break", "local", "for", "while", "if", "function"):
                    return last_end
                prev = "k"
                i = i2
                last_end = i2
                continue
            if prev == "v":
                return last_end
            prev = "v"
            i = i2
            last_end = i2
            continue
        # 其它符号 (运算符等)
        prev = "k"
        i = i2
        last_end = i2
    return last_end


def expand_compound(src):
    mask = mask_string_comment(src)
    edits = []
    for m in COMPOUND.finditer(src):
        op = m.group(2)
        if not op:
            continue
        if mask[m.start()]:
            continue
        lhs = m.group(1).strip()
        if not lhs:
            continue
        rhs_start = m.end()
        rhs_end = scan_expr_end(src, rhs_start, mask)
        rhs = src[rhs_start:rhs_end]
        edits.append((m.start(), rhs_end, "%s = %s %s (%s)" % (lhs, lhs, op, rhs)))
    out = src
    for (a, b, txt) in sorted(edits, key=lambda x: -x[0]):
        out = out[:a] + txt + out[b:]
    return out, len(edits)


GENFOR = re.compile(r"\bfor\b([^\n;]*?)\bin\b([^;\n]*?)\bdo\b")

ITER_FN = "_PhXItEr"

ITER_DEF = (
    "local %s = function(t)\n"
    "  if type(t) == \"table\" then\n"
    "    local mt = getmetatable(t)\n"
    "    if mt and mt.__iter then return mt.__iter(t) end\n"
    "    return next, t, nil\n"
    "  end\n"
    "  return t\n"
    "end\n"
)


def general_for(src, fname=ITER_FN):
    """Luau 广义迭代 for x in T do -> for x in _PhXItEr(T) do
       (Luau: table->next 迭代, function->直接调用; Lua5.x 需运行时分发)"""
    mask = mask_string_comment(src)
    edits = []
    for m in GENFOR.finditer(src):
        a, b = m.start(2), m.end(2)
        if mask[a]:
            continue
        t = m.group(2).strip()
        if not t:
            continue
        if t.startswith("pairs(") or t.startswith("ipairs(") \
           or t.startswith("next") or t.startswith(fname):
            continue
        edits.append((a, b, " %s(%s) " % (fname, t)))
    out = src
    for (a, b, t) in sorted(edits, key=lambda x: -x[0]):
        out = out[:a] + t + out[b:]
    if edits:
        out = ITER_DEF % fname + out
    return out, len(edits)


def preprocess(src):
    src, n0 = general_for(src)
    src, n1 = convert_continue(src)
    src, n2 = expand_compound(src)
    return src, n1, n2


if __name__ == "__main__":
    import sys
    s = open(sys.argv[1]).read()
    out, n1, n2 = preprocess(s)
    open(sys.argv[2], "w").write(out)
    print("continue=%d compound=%d" % (n1, n2))
