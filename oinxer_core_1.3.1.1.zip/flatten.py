#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""控制流平坦化 (Control Flow Flattening)

把每个 proto 的直线指令流切成基本块, 打乱块顺序, 用一个"状态寄存器 + 中央调度器"
决定下一个执行哪个块。静态看到的只剩一个巨大的 dispatch 链, 块间真实先后关系消失。

逆向时这是最难啃的一层: 无法靠线性阅读还原 if/while 结构, 必须先解出状态转移图。
"""
from compiler import Label

JUMPS = ("JMP", "JMPIF", "JMPIFNOT")
TERMINATORS = ("RETURN", "RETURNM")


def _blocks(code):
    """划分基本块, 返回 [(start, end)] (1-based, end 为开区间)"""
    n = len(code)
    leaders = {1}
    for i, ins in enumerate(code, start=1):
        if ins[0] in JUMPS:
            leaders.add(i + 1)
            t = ins[2]
            if 1 <= t <= n:
                leaders.add(t)
    starts = sorted(x for x in leaders if 1 <= x <= n)
    out = []
    for i, s in enumerate(starts):
        e = starts[i + 1] if i + 1 < len(starts) else n + 1
        out.append((s, e))
    return out, {s: i for i, (s, e) in enumerate(out)}


def flatten_proto(P, rng, min_blocks=3):
    """原地平坦化单个 proto。返回 (块数, 新增指令数), 未满足条件则返回 None"""
    code = P.code
    n = len(code)
    if n < 4:
        return None
    blocks, bstart = _blocks(code)
    nb = len(blocks)
    if nb < min_blocks:
        return None

    # 状态寄存器 (放在高位, 不干扰原有分配)
    st = P.maxreg
    P.maxreg += 1

    ids = list(range(nb))
    rng.shuffle(ids)
    order = list(range(nb))
    rng.shuffle(order)

    ir = []
    # 入口状态: blocks[0] 一定以 pc=1 开头 (leaders 含 1), 故 ids[0] 即入口块
    ir.append(("INS", "LOADK", st, P.k(ids[0]), 0))
    ir.append(("LBL", "__DISP"))
    # O(1) 跳转表分派: 取代 v1.2.0 的线性 if 链
    # (线性链对 529 块的 proto 每次转移要跑 ~794 条指令, 是"加载后卡死"的根因)
    ir.append(("INS", "JMPIND", st, 0, 0))

    def goto(pc):
        """生成"转移到 pc 所在块"的尾部"""
        if pc > n:
            ir.append(("INS", "RETURN", 0, 1, 0))
            return
        bi = bstart.get(pc)
        if bi is None:                              # 理论上不会发生(跳转目标必是块首)
            ir.append(("INS", "RETURN", 0, 1, 0))
            return
        ir.append(("INS", "LOADK", st, P.k(ids[bi]), 0))
        ir.append(("J", "JMP", 0, "__DISP"))

    for bi in order:
        ir.append(("LBL", "__B%d" % bi))
        s, e = blocks[bi]
        for pc in range(s, e):
            ins = code[pc - 1]
            op = ins[0]
            if op in TERMINATORS and pc == e - 1:
                ir.append(("INS", op, ins[1], ins[2], ins[3]))
                continue
            if op in JUMPS and pc == e - 1:
                if op == "JMP":
                    goto(ins[2])
                else:
                    # 条件跳转 -> 反条件跳过 + 两路设状态
                    lf = "__F%d_%d" % (bi, pc)
                    ir.append(("J", "JMPIFNOT" if op == "JMPIF" else "JMPIF",
                                ins[1], lf))
                    goto(ins[2])
                    ir.append(("LBL", lf))
                    goto(e)
                continue
            ir.append(("INS", op, ins[1], ins[2], ins[3]))
        # fallthrough 出口
        if e <= n:
            last = code[e - 2] if e >= 2 else None
            if not (last and last[0] in TERMINATORS):
                goto(e)

    # 解析 label -> 绝对 pc
    pos, idx = {}, 1
    for it in ir:
        if it[0] == "LBL":
            pos[it[1]] = idx
        else:
            idx += 1
    out = []
    for it in ir:
        if it[0] == "LBL":
            continue
        if it[0] == "INS":
            out.append([it[1], it[2], it[3], it[4]])
        else:
            out.append([it[1], it[2], pos[it[3]], 0])
    P.code = out
    # 跳转表: 状态值 -> 块首 pc (随 payload 一起加密, 静态不可见)
    P.jt = {ids[bi]: pos["__B%d" % bi] for bi in range(nb)}
    return nb, len(out) - n


def flatten_all(root, rng, min_blocks=3):
    """对 proto 树全部节点做平坦化"""
    tot_b, tot_i = 0, 0
    stack = [root]
    while stack:
        P = stack.pop()
        r = flatten_proto(P, rng, min_blocks)
        if r:
            tot_b += r[0]
            tot_i += r[1]
        stack.extend(P.protos)
    return tot_b, tot_i
