-- Oinxer VM Runtime v1.1.0 (模板; §xxx§ = 构建期占位符)
local §_byte§, §_char§, §_sub§, §_len§ = string.byte, string.char, string.sub, string.len
local §_pack§ = function(...) return {[0] = select('#', ...), ...} end
local §_upk§ = table.unpack or unpack
local §_setm§, §_rawg§, §_raws§ = setmetatable, rawget, rawset
local §_floor§ = math.floor
local §_type§ = type
local §_concat§ = table.concat
local §_tostring§ = tostring

-- ---------- base85 ----------
local §_B85M§ = {}
do
  local §_a§ = §ALPHA§
  for §_i§ = 1, 85 do §_B85M§[§_byte§(§_a§, §_i§)] = §_i§ - 1 end
end
local function §_b85§(§_s§)
  local §_o§, §_n§ = {}, 0
  local §_acc§, §_b§ = 0, 0
  for §_i§ = 1, #§_s§ do
    local §_c§ = §_B85M§[§_byte§(§_s§, §_i§)]
    if §_c§ then
      §_acc§ = §_acc§ * 85 + §_c§
      §_b§ = §_b§ + 1
      if §_b§ >= 5 then
        §_n§ = §_n§ + 1; §_o§[§_n§] = §_floor§(§_acc§ / 16777216) % 256
        §_n§ = §_n§ + 1; §_o§[§_n§] = §_floor§(§_acc§ / 65536) % 256
        §_n§ = §_n§ + 1; §_o§[§_n§] = §_floor§(§_acc§ / 256) % 256
        §_n§ = §_n§ + 1; §_o§[§_n§] = §_acc§ % 256
        §_acc§, §_b§ = 0, 0
      end
    end
  end
  return §_o§
end

local function §_xor§(§_x§, §_y§)
  local §_r§, §_m§ = 0, 1
  while §_x§ > 0 or §_y§ > 0 do
    local §_a§, §_b§ = §_x§ % 2, §_y§ % 2
    if §_a§ ~= §_b§ then §_r§ = §_r§ + §_m§ end
    §_x§ = (§_x§ - §_a§) / 2
    §_y§ = (§_y§ - §_b§) / 2
    §_m§ = §_m§ * 2
  end
  return §_r§
end

local §_s1§, §_s2§ = §SEED1§, §SEED2§
local function §_r1§()
  §_s1§ = (§_s1§ * 48271) % 2147483647
  return §_s1§ % 256
end
local function §_r2§()
  §_s2§ = (§_s2§ * 48271) % 2147483647
  return §_s2§ % 256
end
local function §_xorarr§(§_b§, §_sd§, §_n§)
  §_s2§ = §_sd§
  local §_o§ = {}
  for §_i§ = 1, §_n§ do §_o§[§_i§] = §_xor§(§_b§[§_i§] or 0, §_r2§()) end
  return §_o§
end
local function §_decall§(§_b§)
  for §_i§ = 1, #§_b§ do §_b§[§_i§] = §_xor§(§_b§[§_i§], §_r1§()) end
  return §_b§
end

local function §_rd16§(§_b§, §_p§) return (§_b§[§_p§] or 0) + (§_b§[§_p§ + 1] or 0) * 256 end
local function §_rd32§(§_b§, §_p§)
  return (§_b§[§_p§] or 0) + (§_b§[§_p§ + 1] or 0) * 256 + (§_b§[§_p§ + 2] or 0) * 65536 + (§_b§[§_p§ + 3] or 0) * 16777216
end
local function §_b2s§(§_b§)
  local §_t§, §_c§, §_i§, §_n§ = {}, 0, 1, #§_b§
  while §_i§ <= §_n§ do
    local §_m§ = §_n§ - §_i§ + 1
    if §_m§ > 400 then §_m§ = 400 end
    §_c§ = §_c§ + 1
    §_t§[§_c§] = §_char§(§_upk§(§_b§, §_i§, §_i§ + §_m§ - 1))
    §_i§ = §_i§ + §_m§
  end
  return §_concat§(§_t§)
end

-- ---------- payload 解码 + 置换表 ----------
local §_bl§ = §_decall§(§_b85§(§DATA§))
local §PERMS§ = {}
local §_pstart§
do
  -- payload 首字节为格式版本 (2 = v1.2.1: u32 常量长度 + 平坦化跳转表)
  local §_np§ = §_rd16§(§_bl§, 2)
  local §_q§ = 4
  for §_i§ = 1, §_np§ do
    local §_t§ = {}
    for §_j§ = 0, 255 do §_t§[§_j§] = §_bl§[§_q§] or 0; §_q§ = §_q§ + 1 end
    §PERMS§[§_i§] = §_t§
  end
  §_pstart§ = §_q§
end

-- ============================================================
-- 对抗层 (v1.1.0 新增)
-- ============================================================
local §_TAMPER§ = false
do
  -- 1) 反 hook: 关键库函数若被替换 (tostring 不再含 function/builtin 特征) 判定被分析
  local §_ok§, §_sig§ = pcall(function()
    return §_tostring§(§_tostring§) .. §_tostring§(§_setm§) .. §_tostring§(§_concat§)
  end)
  if not §_ok§ or §_type§(§_sig§) ~= "string" then
    §_TAMPER§ = true
  elseif not (§_sig§:find(§_char§(102,117,110,99,116,105,111,110), 1, true) or §_sig§:find(§_char§(98,117,105,108,116,105,110), 1, true)) then
    §_TAMPER§ = true
  end
  -- 2) 反 dump 仅作环境指纹采集, 不作为判篡改依据
  --    (合法 exploit 环境本身就暴露 getgc/getreg, 若据此判定会使脚本拿到诱饵而失效)
  local §_g§ = _G
  -- 3) 非 Roblox 环境 (沙盒/分析器) 同样视为被分析
  if §_rawg§(§_g§, "game") == nil and §_rawg§(§_g§, "workspace") == nil then
    -- 不置 TAMPER (合法纯 Lua 脚本也需运行), 仅记录指纹用于密钥派生
  end
end

-- 运行时密钥派生: 静态读文件无法得到最终密钥
local §_RK§ = 0
do
  local §_acc§ = 0
  -- 指纹来源: 篡改标志 + 关键函数地址字符串 + 常量环境特征
  local §_fp§ = §_tostring§(§_b85§) .. §_tostring§(§_xorarr§) .. §_tostring§(§_rd32§)
  for §_i§ = 1, #§_fp§ do
    §_acc§ = (§_acc§ * 31 + §_byte§(§_fp§, §_i§)) % 2147483647
  end
  if §_TAMPER§ then §_acc§ = (§_acc§ * 7 + 12345) % 2147483647 end
  §_RK§ = (§_acc§ + §RKBASE§) % 2147483647
  if §_RK§ == 0 then §_RK§ = 1 end
end

-- ============================================================
-- 常量池: 多算法 + 运行时派生密钥 + 诱饵池 (v1.1.0)
-- ============================================================
-- 算法 1: LCG 密钥流 XOR
local function §_algo1§(§_e§, §_sd§)
  local §_s§ = (§_sd§ + §_e§[3] * 7919) % 2147483647
  local §_b§, §_o§ = §_e§[2], {}
  for §_i§ = 1, #§_b§ do
    §_s§ = (§_s§ * 48271) % 2147483647
    §_o§[§_i§] = §_xor§(§_b§[§_i§], §_s§ % 256)
  end
  return §_o§
end
-- 算法 2: 递减加法链
local function §_algo2§(§_e§, §_sd§)
  local §_k§ = (§_sd§ + §_e§[3] * 5407) % 251
  local §_b§, §_o§ = §_e§[2], {}
  for §_i§ = 1, #§_b§ do
    §_o§[§_i§] = (§_b§[§_i§] + §_k§ + §_i§ * 13) % 256
  end
  return §_o§
end
-- 算法 3: 双向异或 + 位置混合
local function §_algo3§(§_e§, §_sd§)
  local §_b§, §_o§, §_n§ = §_e§[2], {}, #§_e§[2]
  local §_k§ = (§_sd§ + §_e§[3] * 3301) % 256
  for §_i§ = 1, §_n§ do
    §_o§[§_i§] = §_xor§(§_b§[§_i§], §_xor§(§_k§, (§_n§ - §_i§ + 1) % 256))
  end
  return §_o§
end
-- 算法 4: 字节重排后再减
local function §_algo4§(§_e§, §_sd§)
  local §_b§, §_o§, §_n§ = §_e§[2], {}, #§_e§[2]
  local §_k§ = (§_sd§ + §_e§[3] * 6151) % 256
  local §_r§ = {}
  for §_i§ = 1, §_n§ do §_r§[§_i§] = §_b§[§_n§ - §_i§ + 1] end
  for §_i§ = 1, §_n§ do §_o§[§_i§] = (§_r§[§_i§] - §_k§ - §_i§) % 256 end
  return §_o§
end
-- 算法 5: 累积链式 (前一字节参与下一字节)
local function §_algo5§(§_e§, §_sd§)
  local §_b§, §_o§ = §_e§[2], {}
  local §_k§ = (§_sd§ + §_e§[3] * 7919) % 256
  local §_prev§ = §_k§
  for §_i§ = 1, #§_b§ do
    §_prev§ = §_xor§(§_b§[§_i§] + §_prev§, §_k§) % 256
    §_o§[§_i§] = §_prev§
  end
  return §_o§
end
local §_ALG§ = { §_algo1§, §_algo2§, §_algo3§, §_algo4§, §_algo5§ }

-- v1.2.1: 常量池只做解密与缓存, 绝不做"静默降级"。
-- 旧版的两条自毁逻辑已删除 —— 它们正是"脚本能加载但丢功能"的根因:
--   1) §_TAMPER§ 为真时把真实常量换成诱饵串 -> 只要执行器 hook 了 tostring 就全盘错值
--   2) 连续递增访问超过 §BULKLIM§(512) 就 rawset(t,k,nil) 永久投毒
--      -> 大表构造器/长初始化序列天然就是升序访问, DOORS 必然触发, 之后该 proto
--         所有常量恒为 nil, 表现为"部分功能消失"且不报错
local function §_pool§(§_enc§)
  return §_setm§({}, {
    __index = function(§_t§, §_k§)
      local §_e§ = §_enc§[§_k§]
      local §_v§
      if §_e§ then
        local §_sd§ = (§SEED2§ + (§_e§[3] or 0) * 104729) % 2147483647
        local §_d§ = §_ALG§[(§_e§[1] % 5) + 1](§_e§, §_sd§)
        if §_e§[5] == 1 then §_v§ = §_b2s§(§_d§)
        elseif §_e§[5] == 0 then
          §_v§ = tonumber(§_b2s§(§_d§))
          if §_v§ == nil then §_v§ = 0 / 0 end   -- NaN 等 tonumber 不收的字面量
        else §_v§ = (§_d§[1] == 1) end
      end
      §_raws§(§_t§, §_k§, §_v§)
      return §_v§
    end
  })
end

-- ---------- 反序列化 ----------
local function §_parse§(§_b§, §_p§)
  local §_all§, §_cnt§ = {}, 0
  local function §_one§()
    local §_nreg§ = §_rd16§(§_b§, §_p§); §_p§ = §_p§ + 2
    local §_nparam§ = §_rd16§(§_b§, §_p§); §_p§ = §_p§ + 2
    local §_pi§ = §_rd16§(§_b§, §_p§); §_p§ = §_p§ + 2
    local §_nk§ = §_rd16§(§_b§, §_p§); §_p§ = §_p§ + 2
    local §_kc§ = {}
    for §_i§ = 1, §_nk§ do
      local §_ty§ = §_b§[§_p§]; §_p§ = §_p§ + 1
      local §_cid§ = §_rd32§(§_b§, §_p§); §_p§ = §_p§ + 4
      local §_al§ = §_b§[§_p§]; §_p§ = §_p§ + 1
      if §_ty§ == 2 then
        §_kc§[§_i§] = { §_al§, { §_b§[§_p§] }, §_cid§, §_i§, §_ty§ }; §_p§ = §_p§ + 1
      else
        local §_ln§ = §_rd32§(§_b§, §_p§); §_p§ = §_p§ + 4
        local §_bl§ = {}
        for §_j§ = 1, §_ln§ do §_bl§[§_j§] = §_b§[§_p§]; §_p§ = §_p§ + 1 end
        §_kc§[§_i§] = { §_al§, §_bl§, §_cid§, §_i§, §_ty§ }
      end
    end
    local §_nu§ = §_rd16§(§_b§, §_p§); §_p§ = §_p§ + 2
    local §_uc§ = {}
    for §_i§ = 1, §_nu§ do
      local §_kd§ = §_b§[§_p§]; §_p§ = §_p§ + 1
      local §_ix§ = §_rd16§(§_b§, §_p§); §_p§ = §_p§ + 2
      §_uc§[§_i§] = { §_kd§, §_ix§ }
    end
    local §_nc§ = §_rd32§(§_b§, §_p§); §_p§ = §_p§ + 4
    local §_cd§ = {}
    for §_i§ = 1, §_nc§ do
      §_cd§[§_i§] = { §_b§[§_p§], §_rd16§(§_b§, §_p§ + 1), §_rd16§(§_b§, §_p§ + 3), §_rd16§(§_b§, §_p§ + 5) }
      §_p§ = §_p§ + 7
    end
    local §_nj§ = §_rd32§(§_b§, §_p§); §_p§ = §_p§ + 4
    local §_jt§ = {}
    for §_i§ = 1, §_nj§ do
      local §_st§ = §_rd32§(§_b§, §_p§); §_p§ = §_p§ + 4
      local §_pc2§ = §_rd32§(§_b§, §_p§); §_p§ = §_p§ + 4
      §_jt§[§_st§] = §_pc2§
    end
    local §_ns§ = §_rd16§(§_b§, §_p§); §_p§ = §_p§ + 2
    local §_sc§ = {}
    for §_i§ = 1, §_ns§ do
      §_sc§[§_i§] = §_rd32§(§_b§, §_p§); §_p§ = §_p§ + 4
    end
    §_cnt§ = §_cnt§ + 1
    §_all§[§_cnt§] = { §_cd§, §_kc§, §_uc§, §_sc§, §_nreg§, §_pi§, §_jt§ }
  end
  local §_np§ = §_rd16§(§_b§, §_p§); §_p§ = §_p§ + 2
  for §_i§ = 1, §_np§ do §_one§() end
  -- 常量池包装 (惰性解密) 与子 proto 引用解析
  for §_i§ = 1, §_cnt§ do
    §_all§[§_i§][2] = §_pool§(§_all§[§_i§][2])
  end
  for §_i§ = 1, §_cnt§ do
    local §_ss§ = §_all§[§_i§][4]
    for §_j§ = 1, #§_ss§ do §_ss§[§_j§] = §_all§[§_ss§[§_j§] + 1] end
  end
  return §_all§[1]
end

local §_G0§ = _G
if §_type§(getfenv) == "function" then
  local §_ok§, §_e§ = pcall(getfenv)
  if §_ok§ and §_e§ then §_G0§ = §_e§ end
end

-- ============================================================
-- 解释器: handler 闭包数组 (O(1) 分派, v1.1.0)
-- ============================================================
local §_REG§ = §_setm§({}, {__mode = "k"})
local §_mk§, §_interp§

-- 当前栈帧状态 (upvalue, 由 handler 直接访问)
local §_R§, §_K§, §_U§, §_SUB§, §_TOP§, §_n§, §_pc§, §_A§, §_B§, §_C§, §_JT§, §_CL§
local §_ARGS§, §_NA§, §_G§, §_RES§
local §_H§ = {}
§HANDLERS§

-- 运行时二次编号: 用运行时派生随机源重排 handler 编号与所有置换表
-- 效果: 静态读文件得到的 opcode 编号在本次运行之外一律无效
do
  local §_g§ = {}
  do
    local §_sl§ = {}
    for §_i§ = 0, 255 do §_sl§[§_i§ + 1] = §_i§ end
    local §_rs§ = §_RK§
    for §_i§ = 255, 1, -1 do
      §_rs§ = (§_rs§ * 48271) % 2147483647
      local §_j§ = (§_rs§ % (§_i§ + 1)) + 1
      §_sl§[§_i§ + 1], §_sl§[§_j§] = §_sl§[§_j§], §_sl§[§_i§ + 1]
    end
    for §_i§ = 0, 255 do §_g§[§_i§] = §_sl§[§_i§ + 1] end
  end
  local §_NH§ = {}
  for §_i§ = 0, 255 do
    if §_H§[§_i§] then §_NH§[§_g§[§_i§]] = §_H§[§_i§] end
  end
  for §_pi§ = 1, #§PERMS§ do
    local §_pm§ = §PERMS§[§_pi§]
    for §_k§ = 0, 255 do
      local §_v§ = §_pm§[§_k§]
      if §_v§ then §_pm§[§_k§] = §_g§[§_v§] end
    end
  end
  §_H§ = §_NH§
end

§_interp§ = function(§_P§, §_u§, §_args§, §_g§)
  local §_oR§, §_oK§, §_oU§, §_oS§, §_oT§ = §_R§, §_K§, §_U§, §_SUB§, §_TOP§
  local §_oG§, §_oA§, §_oN§, §_oRS§ = §_G§, §_ARGS§, §_NA§, §_RES§
  local §_opc§, §_on§ = §_pc§, §_n§
  local §_sA§, §_sB§, §_sC§ = §_A§, §_B§, §_C§
  local §_oJT§, §_oCL§ = §_JT§, §_CL§
  local §_code§, §_KP§ = §_P§[1], §_P§[2]
  local §_perm§ = §PERMS§[§_P§[6]]
  §_JT§ = §_P§[7] or {}
  §_CL§ = #§_code§
  §_R§ = {}
  §_K§ = §_KP§
  §_U§ = §_u§
  §_SUB§ = §_P§[4]
  §_TOP§ = -1
  §_G§ = §_g§
  §_ARGS§ = §_args§
  §_RES§ = nil
  §_NA§ = §_args§[0] or #§_args§
  for §_i§ = 1, §_NA§ do §_R§[§_i§ - 1] = §_args§[§_i§] end
  §_pc§ = 1
  -- 异常安全: error 抛出会跳过帧恢复代码, 必须用 pcall 包裹,
  -- 捕获后先还原上一层帧状态再原样 rethrow, 否则外层继续用脏寄存器执行
  local §_r§
  local §_ok§, §_err§ = pcall(function()
    while true do
      local §_i§ = §_code§[§_pc§]
      if §_i§ == nil then break end
      local §_o§ = §_perm§[§_i§[1]]
      §_A§, §_B§, §_C§ = §_i§[2], §_i§[3], §_i§[4]
      local §_h§ = §_H§[§_o§]
§TRACE§
      §_n§ = §_pc§ + 1
      if §_h§ then §_h§() end
      if §_RES§ then break end
      §_pc§ = §_n§
    end
    §_r§ = §_RES§
  end)
  §_R§, §_K§, §_U§, §_SUB§, §_TOP§ = §_oR§, §_oK§, §_oU§, §_oS§, §_oT§
  §_JT§, §_CL§ = §_oJT§, §_oCL§
  §_G§, §_ARGS§, §_NA§, §_RES§ = §_oG§, §_oA§, §_oN§, §_oRS§
  §_pc§, §_n§ = §_opc§, §_on§
  §_A§, §_B§, §_C§ = §_sA§, §_sB§, §_sC§
  if not §_ok§ then error(§_err§, 0) end
  return §_r§
end

§_mk§ = function(§_P§, §_U§)
  local §_f§ = function(...)
    local §_r§ = §_interp§(§_P§, §_U§, §_pack§(...), §_G0§)
    if §_r§ == nil then return nil end
    return §_upk§(§_r§, 1, §_r§[0] or #§_r§)
  end
  §_REG§[§_f§] = {§_P§, §_U§}
  return §_f§
end

-- ---------- 启动 ----------
return §_mk§(§_parse§(§_bl§, §_pstart§), {})
