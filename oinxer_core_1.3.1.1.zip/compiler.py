#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Lua/Luau  ->  自定义寄存器式 VM 字节码 编译器
用于构建 Luraph 级别的 VM 混淆 (Phoenix Obfuscator 前端)

指令集 (内部名, 最终映射为随机 opcode 编号):
  LOADK    A K        R[A] = K[K]
  LOADNIL  A          R[A] = nil
  LOADBOOL A B        R[A] = (B == 1)
  MOVE     A B        R[A] = R[B]
  BOX      A          R[A] = {[1] = R[A]}
  GETBOX   A B        R[A] = R[B][1]
  SETBOX   A B        R[A][1] = R[B]
  GETGLOBAL A K       R[A] = G[K[K]]
  SETGLOBAL A K       G[K[K]] = R[A]
  GETUPVAL A U        R[A] = U[U][1]
  SETUPVAL A U        U[U][1] = R[A]
  GETTABLE A B C      R[A] = R[B][R[C]]
  SETTABLE A B C      R[A][R[B]] = R[C]
  GETFIELD A B K      R[A] = R[B][K[K]]
  SETFIELD A B K      R[A][K[K]] = R[B]     (注意: A=表, B=值, K=键)
  NEWTABLE A B        R[A] = {}
  SETLIST  A I B      R[A][I] = R[B]
  SETLISTM A I B      R[A][I..] = R[B..TOP]
  CALL     A B C      R[A..A+C-2] = R[A](R[A+1..A+B-1]) ; B=0 表示参数到 TOP
  CALLM    A B        R[A..TOP]  = R[A](R[A+1..A+B-1]) ; B=0 同上
  RETURN   A B        return R[A..A+B-2]
  RETURNM  A          return R[A..TOP]
  VARARG   A B        R[A..A+B-2] = ...
  VARARGM  A          R[A..TOP] = ...
  JMP      s P        pc = P
  JMPIF    A P        if R[A] then pc = P
  JMPIFNOT A P        if not R[A] then pc = P
  ADD/SUB/MUL/DIV/MOD/POW  A B C   R[A] = R[B] op R[C]
  UNM/NOT/LEN         A B          R[A] = op R[B]
  CONCAT   A B C      R[A] = R[B] .. R[C]
  EQ/NE/LT/LE         A B C        R[A] = (R[B] op R[C])
  CLOSURE  A P        R[A] = closure(protos[P])
  DEAD     *          死代码 (不执行任何事)
"""

from luaparser import ast
from luaparser import astnodes as N


def tn(n):
    return type(n).__name__


def S(node):
    """String 节点的实际内容 (luaparser 给的是 bytes)"""
    s = node.s
    if isinstance(s, bytes):
        return s.decode("utf-8", "surrogateescape")
    return s


def isdot(e):
    """t.x 这种点号取字段 (区别于 t[x])"""
    nt = getattr(e, "notation", None)
    return nt is not None and getattr(nt, "_name_", "") == "DOT"


def skey(node):
    """表构造/索引里的字面量字符串键 -> str 或 None"""
    t = tn(node)
    if t == "String":
        return S(node)
    if t == "Name":
        return node.id
    return None


def uses_map(node, depth=0, out=None):
    """{name: set(depth)} —— 判断哪些 local 会被内层函数捕获 (保守策略)"""
    if out is None:
        out = {}
    if node is None:
        return out
    if isinstance(node, (list, tuple)):
        for x in node:
            uses_map(x, depth, out)
        return out
    if not hasattr(node, "__dict__"):
        return out
    t = tn(node)
    nd = depth
    if t in ("LocalFunction",):
        # 函数名属于外层作用域, 只有 body/args 属于内层
        uses_map(getattr(node, "name", None), depth, out)
        for a in getattr(node, "args", None) or []:
            uses_map(a, depth + 1, out)
        uses_map(getattr(node, "body", None), depth + 1, out)
        return out
    if t in ("Function", "Method"):
        for fld in ("name", "source"):
            uses_map(getattr(node, fld, None), depth, out)
        for a in getattr(node, "args", None) or []:
            uses_map(a, depth + 1, out)
        uses_map(getattr(node, "body", None), depth + 1, out)
        return out
    if t == "AnonymousFunction":
        for a in getattr(node, "args", None) or []:
            uses_map(a, depth + 1, out)
        uses_map(getattr(node, "body", None), depth + 1, out)
        return out
    if t == "Name":
        out.setdefault(node.id, set()).add(depth)
    for k, v in node.__dict__.items():
        if k.startswith("_"):
            continue
        if hasattr(v, "__dict__") or isinstance(v, (list, tuple)):
            uses_map(v, nd, out)
    return out


BINOPS = {
    "AddOp": "ADD", "SubOp": "SUB", "MultOp": "MUL", "FloatDivOp": "DIV",
    "ModOp": "MOD", "ExpoOp": "POW", "Concat": "CONCAT",
    "FloorDivOp": "FDIV",
    "EqToOp": "EQ", "NotEqToOp": "NE",
    "LessThanOp": "LT", "LessOrEqThanOp": "LE",
    "GreaterThanOp": "LT", "GreaterOrEqThanOp": "LE",
    "AndLoOp": "AND", "OrLoOp": "OR",
}
SWAPOPS = {"GreaterThanOp", "GreaterOrEqThanOp"}
UNOPS = {"UMinusOp": "UNM", "ULengthOP": "LEN", "ULNotOp": "NOT"}
MULTI = ("Call", "Invoke")
VARARG_NODES = ("Varargs", "Dots")


def is_multi(v):
    """会产生多个值的表达式 (调用 / ... ); 被括号包裹时截断为单值"""
    if getattr(v, "wrapped", False):
        return False
    return tn(v) in MULTI or tn(v) in VARARG_NODES


class Label(object):
    __slots__ = ("pos",)

    def __init__(self):
        self.pos = None


class Proto(object):
    def __init__(self, name, parent, depth):
        self.name = name
        self.parent = parent
        self.depth = depth
        self.code = []
        self.consts = []
        self.kmap = {}
        self.protos = []
        self.nparam = 0
        self.is_vararg = False
        self.maxreg = 0
        self.scopes = []
        self.upvals = []        # [(name, 'reg'|'up', idx)]
        self.upmap = {}
        self.captured = set()
        self.boxdone = set()
        self.brk = []
        self.cont = []

    def reg(self, n=1):
        r = self.maxreg
        self.maxreg += n
        return r

    def emit(self, op, a=0, b=0, c=0):
        self.code.append([op, a, b, c])
        return len(self.code) - 1

    def here(self, L):
        L.pos = len(self.code)

    def k(self, v):
        key = (type(v).__name__, v)
        if key in self.kmap:
            return self.kmap[key]
        self.consts.append(v)
        i = len(self.consts) - 1
        self.kmap[key] = i
        return i

    def push(self):
        self.scopes.append({})

    def pop(self):
        self.scopes.pop()

    def declare(self, name):
        r = self.reg()
        self.scopes[-1][name] = r
        return r

    def lookup_local(self, name):
        for s in reversed(self.scopes):
            if name in s:
                return s[name]
        return None

    def add_upval(self, name, kind, idx):
        if name in self.upmap:
            return self.upmap[name]
        self.upvals.append((name, kind, idx))
        i = len(self.upvals) - 1
        self.upmap[name] = i
        return i

    def resolve(self, name):
        r = self.lookup_local(name)
        if r is not None:
            return ("boxed" if name in self.captured else "local", r)
        if self.parent is not None:
            pr = self.parent._lookup_outer(name)
            if pr is not None:
                kind, idx = pr
                return ("upval", self.add_upval(name, kind, idx))
        return ("global", None)

    def _lookup_outer(self, name):
        r = self.lookup_local(name)
        if r is not None:
            return ("reg", r)
        if self.parent is not None:
            pr = self.parent._lookup_outer(name)
            if pr is not None:
                kind, idx = pr
                return ("up", self.add_upval(name, kind, idx))
        return None


class Compiler(object):
    def compile(self, src):
        tree = ast.parse(src)
        P = Proto("main", None, 0)
        self.root = P
        self.func(P, tree.body, [], True)
        P.emit("RETURN", 0, 1)
        return P

    # ---------------- 函数体 ----------------
    def func(self, P, block, params, is_main=False):
        # 1) 预扫描捕获
        u = uses_map(block, 0)
        for name, depths in u.items():
            if any(d > 0 for d in depths):
                P.captured.add(name)
        P.push()
        # 2) 参数
        for a in params:
            if tn(a) in ("Varargs", "Dots"):
                P.is_vararg = True
            else:
                self.declare_local(P, a.id)
                P.nparam += 1
        # 3) body
        self.block(P, block)
        P.pop()

    def block(self, P, block, pre=None):
        P.push()
        if pre:
            for k, v in pre.items():
                P.scopes[-1][k] = v
        for st in block.body:
            self.stmt(P, st)
        P.pop()

    def declare_local(self, P, name):
        """声明 local; 若会被捕获则先建 box (保证闭包能捕获到同一个 box)"""
        r = P.reg()
        P.scopes[-1][name] = r
        if name in P.captured and r not in P.boxdone:
            P.emit("BOX", r)
            P.boxdone.add(r)
        return r

    def store_local(self, P, name, src):
        """写入 local (自动处理 box)"""
        r = P.lookup_local(name)
        if r is None:
            raise Exception("store_local: undefined " + name)
        if name in P.captured:
            P.emit("SETBOX", r, src)
        else:
            P.emit("MOVE", r, src)

    # ---------------- 语句 ----------------
    def stmt(self, P, st):
        t = tn(st)
        f = getattr(self, "s_" + t, None)
        if f is None:
            raise Exception("unsupported statement: " + t)
        f(P, st)

    def s_LocalAssign(self, P, st):
        tg = st.targets
        vals = st.values or []
        if len(vals) == 1 and is_multi(vals[0]):
            base = P.reg(len(tg))
            if tn(vals[0]) in MULTI:
                self.expr_multi(P, vals[0], base)
            else:
                P.emit("VARARGM", base)
            for i, t in enumerate(tg):
                if tn(t) == "Name":
                    self.declare_local(P, t.id)
                    self.store_local(P, t.id, base + i)
                else:
                    self.assign_target(P, t, base + i)
            return
        # 注意: Lua 语义下 "local f = function() ... f() ... end" 中右侧的 f
        # 指向全局(尚未声明), 故必须先求值再声明, 不可提前绑定寄存器。
        regs = []
        for i, t in enumerate(tg):
            regs.append(self.expr(P, vals[i]) if i < len(vals) else self.nilr(P))
        for i, t in enumerate(tg):
            if tn(t) == "Name":
                self.declare_local(P, t.id)
                self.store_local(P, t.id, regs[i])
            else:
                self.assign_target(P, t, regs[i])

    def s_Assign(self, P, st):
        tg = st.targets
        vals = st.values or []
        if len(vals) == 1 and is_multi(vals[0]):
            base = P.reg(len(tg))
            if tn(vals[0]) in MULTI:
                self.expr_multi(P, vals[0], base)
            else:
                P.emit("VARARGM", base)
            for i, t in enumerate(tg):
                self.assign_target(P, t, base + i)
            return
        regs = [self.expr(P, v) for v in vals]
        for i, t in enumerate(tg):
            self.assign_target(P, t, regs[i] if i < len(regs) else self.nilr(P))

    def nilr(self, P):
        r = P.reg()
        P.emit("LOADNIL", r)
        return r

    def assign_target(self, P, tg, src):
        t = tn(tg)
        if t == "Name":
            kind, idx = P.resolve(tg.id)
            if kind == "local":
                P.emit("MOVE", idx, src)
            elif kind == "boxed":
                P.emit("SETBOX", idx, src)
            elif kind == "upval":
                P.emit("SETUPVAL", src, idx)
            else:
                P.emit("SETGLOBAL", src, P.k(tg.id))
        elif t == "Index":
            obj = self.expr(P, tg.value)
            sk = skey(tg.idx) if isdot(tg) else None
            if sk is None and tn(tg.idx) == "String":
                sk = S(tg.idx)
            if sk is not None:
                P.emit("SETFIELD", obj, P.k(sk), src)
            else:
                kk = self.expr(P, tg.idx)
                P.emit("SETTABLE", obj, kk, src)
        else:
            raise Exception("assign target " + t)

    def s_LocalFunction(self, P, st):
        name = st.name.id
        self.declare_local(P, name)          # 若被捕获: 先建空 box
        self.mk_closure(P, name, st.args, st.body)

    def s_Function(self, P, st):
        tmp = P.reg()
        args = list(st.args)
        # method: function t:m() -> 隐式 self
        if getattr(st, "is_method", False) or getattr(st, "method", False):
            args = [N.Name("self")] + args
        self.mk_closure(P, "anon", args, st.body, dst=tmp)
        self.assign_target(P, st.name, tmp)

    def mk_closure(self, P, name, args, body, dst=None):
        """创建闭包并赋给 local name; 若 name 是 captured local 则写入其 box"""
        r = dst
        boxed = False
        if r is None:
            r = P.lookup_local(name)
            boxed = (name in P.captured)
        sub = Proto(name, P, P.depth + 1)
        P.protos.append(sub)
        idx = len(P.protos) - 1
        P.emit("CLOSUREB" if boxed else "CLOSURE", r, idx)
        self.func(sub, body, args)
        sub.emit("RETURN", 0, 1)

    def s_Method(self, P, st):
        """function obj:method(args) -- 隐式 self"""
        tmp = P.reg()
        args = [N.Name("self")] + list(st.args)
        self.mk_closure(P, "method", args, st.body, dst=tmp)
        obj = self.expr(P, st.source)
        P.emit("SETFIELD", obj, P.k(st.name.id), tmp)
        tmp2 = None

    def s_Do(self, P, st):
        self.block(P, st.body)

    def s_If(self, P, st):
        end = Label()
        self.if_chain(P, st, end)
        P.here(end)

    def if_chain(self, P, node, end):
        t = tn(node)
        if t in ("If", "ElseIf"):
            test = self.expr(P, node.test)
            nxt = Label()
            P.emit("JMPIFNOT", test, nxt)
            self.block(P, node.body)
            if node.orelse is not None:
                P.emit("JMP", 0, end)
                P.here(nxt)
                self.if_chain(P, node.orelse, end)
            else:
                P.here(nxt)
        elif t == "Else":
            self.block(P, node.body)
        elif t == "Block":
            self.block(P, node)
        else:
            raise Exception("if_chain " + t)

    def s_While(self, P, st):
        start, end, cont = Label(), Label(), Label()
        P.here(start)
        t = self.expr(P, st.test)
        P.emit("JMPIFNOT", t, end)
        P.brk.append(end)
        P.cont.append(cont)
        self.block(P, st.body)
        P.cont.pop()
        P.brk.pop()
        P.here(cont)
        P.emit("JMP", 0, start)
        P.here(end)

    def s_Repeat(self, P, st):
        start, end, cont = Label(), Label(), Label()
        P.here(start)
        P.brk.append(end)
        P.cont.append(cont)
        self.block(P, st.body)
        P.cont.pop()
        P.here(cont)
        t = self.expr(P, st.test)
        P.brk.pop()
        P.emit("JMPIFNOT", t, start)
        P.here(end)

    def s_Fornum(self, P, st):
        P.push()
        i = P.declare(st.target.id)
        lim = P.reg()
        step = P.reg()
        self.expr_into(P, st.start, i)
        self.expr_into(P, st.stop, lim)
        if st.step is not None and hasattr(st.step, "__dict__"):
            self.expr_into(P, st.step, step)
        else:
            P.emit("LOADK", step, P.k(1))
        if st.target.id in P.captured:
            raise Exception("loop variable captured - unsupported")

        pre, body, neg, end = Label(), Label(), Label(), Label()
        cont = Label()
        P.here(pre)
        t1 = P.reg()
        P.emit("LE", t1, lim, i)          # t1 = (lim <= i)  即 i >= lim
        t2 = P.reg()
        P.emit("LE", t2, i, lim)          # t2 = (i <= lim)
        z = P.reg()
        P.emit("LOADK", z, P.k(0))
        t3 = P.reg()
        P.emit("LE", t3, z, step)         # t3 = (0 <= step)
        P.emit("JMPIFNOT", t3, neg)
        P.emit("JMPIFNOT", t2, end)       # step>=0 且 i>lim -> 结束
        P.emit("JMP", 0, body)
        P.here(neg)
        P.emit("JMPIFNOT", t1, end)       # step<0 且 i<lim -> 结束
        P.here(body)
        P.brk.append(end)
        P.cont.append(cont)
        self.block(P, st.body)
        P.cont.pop()
        P.here(cont)
        P.brk.pop()
        P.emit("ADD", i, i, step)
        P.emit("JMP", 0, pre)
        P.here(end)
        P.pop()

    def s_Forin(self, P, st):
        P.push()
        S = P.reg(3)              # S=f, S+1=s, S+2=ctl
        it = list(st.iter)
        if len(it) == 1:
            b = P.reg(3)
            self.expr_multi(P, it[0], b, 3)
            P.emit("MOVE", S, b)
            P.emit("MOVE", S + 1, b + 1)
            P.emit("MOVE", S + 2, b + 2)
        else:
            self.expr_into(P, it[0], S)
            self.expr_into(P, it[1], S + 1)
            if len(it) > 2:
                self.expr_into(P, it[2], S + 2)
            else:
                P.emit("LOADNIL", S + 2)
        loop, ok, end, cont = Label(), Label(), Label(), Label()
        P.here(loop)
        R = P.reg(3)              # R, R+1 = 迭代结果 ; R+2 为参数区
        P.emit("MOVE", R, S)
        P.emit("MOVE", R + 1, S + 1)
        P.emit("MOVE", R + 2, S + 2)
        P.emit("CALL", R, 3, 3)   # R, R+1 = f(s, ctl)
        P.emit("JMPIF", R, ok)
        P.emit("JMP", 0, end)
        P.here(ok)
        P.emit("MOVE", S + 2, R)  # ctl = 第一个返回值
        for k, tg in enumerate(st.targets):
            if tn(tg) == "Name":
                r = P.declare(tg.id)
                P.emit("MOVE", r, R + k)
                if tg.id in P.captured:
                    P.emit("BOX", r)
            else:
                self.assign_target(P, tg, R + k)
        P.brk.append(end)
        P.cont.append(cont)
        self.block(P, st.body)
        P.cont.pop()
        P.here(cont)
        P.brk.pop()
        P.emit("JMP", 0, loop)
        P.here(end)
        P.pop()

    def s_Break(self, P, st):
        if not P.brk:
            raise Exception("break outside loop")
        P.emit("JMP", 0, P.brk[-1])

    def s_Return(self, P, st):
        vals = st.values or []
        if not vals:
            P.emit("RETURN", 0, 1)
            return
        if len(vals) == 1:
            v = vals[0]
            if tn(v) in MULTI:
                base = P.reg(1)
                self.expr_multi(P, v, base)
                P.emit("RETURNM", base)
                return
            if tn(v) in ("Varargs", "Dots"):
                base = P.reg(1)
                P.emit("VARARGM", base)
                P.emit("RETURNM", base)
                return
        base = P.reg(len(vals))
        lastv = vals[-1]
        for i, v in enumerate(vals):
            if i == len(vals) - 1 and is_multi(v):
                if tn(v) in MULTI:
                    self.expr_multi(P, v, base + i)
                else:
                    P.emit("VARARGM", base + i)
                P.emit("RETURNM", base)
                return
            self.expr_into(P, v, base + i)
        P.emit("RETURN", base, len(vals) + 1)

    def s_Call(self, P, st):
        f = getattr(st, "func", None)
        if tn(f) == "Name" and f.id == "__PHX_CONTINUE__":
            if not P.cont:
                raise Exception("continue outside loop")
            P.emit("JMP", 0, P.cont[-1])
            return
        self.expr_call(P, st, P.reg(1 + len(st.args or [])), 0)

    def s_Invoke(self, P, st):
        self.expr_call(P, st, P.reg(2 + len(st.args or [])), 0)

    def s_Goto(self, P, st):
        raise Exception("goto unsupported - rewrite with if/while")

    def s_Label(self, P, st):
        pass

    def s_Nop(self, P, st):
        pass

    def s_SemiColon(self, P, st):
        pass

    def s_Comment(self, P, st):
        pass

    # ---------------- 表达式 ----------------
    def expr_into(self, P, e, dst):
        r = self.expr(P, e)
        if r != dst:
            P.emit("MOVE", dst, r)

    def expr(self, P, e):
        t = tn(e)
        # 兜底: luaparser 有时直接给字面量 (如 for 的默认 step=1)
        if isinstance(e, bool):
            r = P.reg()
            P.emit("LOADBOOL", r, 1 if e else 0)
            return r
        if isinstance(e, (int, float)):
            r = P.reg()
            P.emit("LOADK", r, P.k(e))
            return r
        if isinstance(e, str):
            r = P.reg()
            P.emit("LOADK", r, P.k(e))
            return r
        if t == "Number":
            r = P.reg()
            P.emit("LOADK", r, P.k(e.n))
            return r
        if t == "String":
            r = P.reg()
            P.emit("LOADK", r, P.k(S(e)))
            return r
        if t == "TrueExpr":
            r = P.reg()
            P.emit("LOADBOOL", r, 1)
            return r
        if t == "FalseExpr":
            r = P.reg()
            P.emit("LOADBOOL", r, 0)
            return r
        if t == "Nil":
            r = P.reg()
            P.emit("LOADNIL", r)
            return r
        if t == "Name":
            r = P.reg()
            kind, idx = P.resolve(e.id)
            if kind == "local":
                P.emit("MOVE", r, idx)
            elif kind == "boxed":
                P.emit("GETBOX", r, idx)
            elif kind == "upval":
                P.emit("GETUPVAL", r, idx)
            else:
                P.emit("GETGLOBAL", r, P.k(e.id))
            return r
        if t == "Index":
            r = P.reg()
            obj = self.expr(P, e.value)
            sk = skey(e.idx) if isdot(e) else None
            if sk is None and tn(e.idx) == "String":
                sk = S(e.idx)
            if sk is not None:
                P.emit("GETFIELD", r, obj, P.k(sk))
            else:
                kk = self.expr(P, e.idx)
                P.emit("GETTABLE", r, obj, kk)
            return r
        if t in BINOPS:
            return self.binop(P, e, t)
        if t in UNOPS:
            r = P.reg()
            a = self.expr(P, e.operand)
            P.emit(UNOPS[t], r, a)
            return r
        if t in MULTI:
            r = P.reg()
            self.expr_call(P, e, r, 1)
            return r
        if t == "Table":
            return self.table(P, e)
        if t == "Function" or t == "AnonymousFunction":
            r = P.reg()
            args = list(e.args)
            self.mk_closure(P, "anon", args, e.body, dst=r)
            return r
        if t in ("Varargs", "Dots"):
            r = P.reg()
            P.emit("VARARG", r, 2)
            return r
        if t == "Paren":
            return self.expr(P, e.exp)
        raise Exception("unsupported expr: " + t)

    def binop(self, P, e, t):
        if t == "AndLoOp":
            r = P.reg()
            self.expr_into(P, e.left, r)
            L = Label()
            P.emit("JMPIFNOT", r, L)
            self.expr_into(P, e.right, r)
            P.here(L)
            return r
        if t == "OrLoOp":
            r = P.reg()
            self.expr_into(P, e.left, r)
            L = Label()
            P.emit("JMPIF", r, L)
            self.expr_into(P, e.right, r)
            P.here(L)
            return r
        a = self.expr(P, e.left)
        b = self.expr(P, e.right)
        if t in SWAPOPS:
            a, b = b, a
        r = P.reg()
        P.emit(BINOPS[t], r, a, b)
        return r

    def table(self, P, e):
        r = P.reg()
        P.emit("NEWTABLE", r, len(e.fields))
        arr = 0
        last = e.fields[-1] if e.fields else None
        for fd in e.fields:
            key, val = fd.key, fd.value
            if key is None:
                arr += 1
                vr = P.reg()
                if tn(val) in MULTI and fd is last:
                    self.expr_multi(P, val, vr)
                    P.emit("SETLISTM", r, arr, vr)
                else:
                    self.expr_into(P, val, vr)
                    P.emit("SETLIST", r, arr, vr)
            elif skey(key) is not None:
                vr = P.reg()
                self.expr_into(P, val, vr)
                P.emit("SETFIELD", r, P.k(skey(key)), vr)
            else:
                kr = self.expr(P, key)
                vr = P.reg()
                self.expr_into(P, val, vr)
                P.emit("SETTABLE", r, kr, vr)
        return r

    # ---------------- 调用 ----------------
    def _setup_call(self, P, e, base):
        """在 base 放好函数/self, 返回第一个参数的寄存器 和 参数个数B"""
        args = e.args or []
        if tn(e) == "Invoke":
            src = self.expr(P, e.source)
            P.emit("GETFIELD", base, src, P.k(e.func.id))
            P.emit("MOVE", base + 1, src)
            first = base + 2
            nb = len(args) + 2
        else:
            self.expr_into(P, e.func, base)
            first = base + 1
            nb = len(args) + 1
        n = len(args)
        for i, a in enumerate(args):
            if i == n - 1 and is_multi(a):
                if tn(a) in MULTI:
                    self.expr_multi(P, a, first + i)
                else:
                    P.emit("VARARGM", first + i)
                nb = 0
            else:
                self.expr_into(P, a, first + i)
        return nb

    def expr_call(self, P, e, base, nres):
        nb = self._setup_call(P, e, base)
        P.emit("CALL", base, nb, nres + 1)

    def expr_multi(self, P, e, base, nwant=1):
        t = tn(e)
        if t in ("Call", "Invoke"):
            nb = self._setup_call(P, e, base)
            P.emit("CALLM", base, nb)
        elif t in VARARG_NODES:
            P.emit("VARARGM", base)
        else:
            # 非多值表达式: 只填第一个, 其余补 nil
            self.expr_into(P, e, base)
            for i in range(1, max(nwant, 1)):
                P.emit("LOADNIL", base + i)


# ---------------- patch ----------------
def patch(proto):
    def fix(P):
        for ins in P.code:
            for i in range(1, 4):
                if isinstance(ins[i], Label):
                    ins[i] = ins[i].pos + 1
        for s in P.protos:
            fix(s)
    fix(proto)


def _finish_forin(P):
    """在 s_Forin 之后补齐 body (由 post_pass 调用)"""
    pass


def all_protos(p):
    out = [p]
    for s in p.protos:
        out.extend(all_protos(s))
    return out
