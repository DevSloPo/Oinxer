#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Oinxer Obfuscator (Luraph Special Edition) v1.3.1
=====================================================
主题: 体积压缩 + 大文件稳定性。目标 —— 大脚本产物压在 600~800KB, 不再过 MB。

v1.3.0 实测体积构成 (DOORS, 源码 334KB -> 产物 2.31MB):
    常量池 ~780KB   (三池 x 全槽位, 其中 66% 是逐个加密的诱饵)
    指令   ~553KB   (79041 条 x 定长 7 字节)
    置换表 ~132KB   (518 proto x 256 字节独立置换)
    跳转表 ~49KB
  payload 1.43MB -> base85 1.79MB -> L0 再编码 2.31MB

v1.3.1 的四处结构性压缩:
  C1 诱饵不再落盘    未使用槽位只写 1 字节标记(3), 运行时由位置派生诱饵填充。
                    拖库看到的仍是真假混杂, 但文件里不占体积。  -约 490KB
  C2 置换表共享池    518 套独立置换 -> NPERM(16) 套, proto 按索引分组。
                    同时把启动时构建的 handler 数组从 518x256 降到 16x256,
                    启动不再因十几万次闭包重映射而卡死。          -约 128KB
  C3 指令变长编码    opcode u8 + A/B/C 各 varint。绝大多数操作数 < 128,
                    平均 7 -> 约 4.3 字节。                      -约 200KB
  C4 紧凑常量头      去掉每槽 4 字节 cid(改为 (proto,pool,slot) 派生),
                    长度字段改 varint。                          -约 90KB

另加大文件自适应: 指令规模超阈值时自动降低死指令密度、限制平坦化,
避免大脚本在体积与执行开销上双重失控。
"""
import sys, os, random, string, zlib
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import oinxer_v13 as V13
import oinxer_v11 as V
from oinxer_v11 import ALGOS, u16, u32, lua_str, chunk_data
from build import (run_lua, fmt_num, DISPATCH, ALL_OPS, KFIELDS, PFIELDS, UFIELDS,
                   xor_all, b85_encode, strip_tpl_comments, LUA_KW, mangle)
from compiler import Compiler, patch, all_protos, Label
from flatten import flatten_all, flatten_proto
from luraph_mode import (NPOOL, const_usage, gen_decoy)

HERE = os.path.dirname(os.path.abspath(__file__))

NOISE_OPS = V13.NOISE_OPS
ALL_OPS13 = V13.ALL_OPS13
DISPATCH13 = V13.DISPATCH13

NPERM = 16          # 置换表共享池大小
FMT_V = 3           # payload 格式版本


# ---------------- 变长整数 ----------------
def vint(v):
    v = int(v)
    if v < 0:
        v = 0
    if v < 128:
        return bytes([v])
    if v < 32512:
        # 首字节 128..254; 255 保留为长整型转义标记
        return bytes([128 + (v >> 8), v & 255])
    return bytes([255, (v >> 24) & 255, (v >> 16) & 255, (v >> 8) & 255, v & 255])


def cid_of(proto_idx0, pool, slot1):
    """与 VM 侧 §_cid§ 完全一致的派生式常量 id。

    VM: (§_pi§ - 1) * 100003 + (§_PLIDX§ - 1) * 10007 + §_i§
      §_pi§    = proto 序号 + 1  (序列化写入的字段)
      §_PLIDX§ = 池号 1..3
      §_i§     = 槽位 1..nk
    """
    return proto_idx0 * 100003 + pool * 10007 + slot1


# ---------------- 常量池 (C1 + C4) ----------------
def ser_const_pool_v131(p, seed2, proto_idx0, rng):
    nk = len(p.consts)
    used = getattr(p, "_pool_used", None) or const_usage(p)
    out = bytearray()
    out += u16(nk)
    for pi in range(NPOOL):
        algos = V13.__dict__.get("POOL_ALGOS")
        if algos is None:
            from luraph_mode import POOL_ALGOS as algos
        algos = algos[pi]
        sp = (seed2 + pi * 104729 * 104729) % 2147483647
        for i in range(nk):
            if i not in used[pi]:
                out += bytes([3])          # 诱饵槽: 1 字节, 运行时派生
                continue
            cid = cid_of(proto_idx0, pi, i + 1)
            c = p.consts[i]
            if isinstance(c, bool):
                out += bytes([2]) + bytes([rng.randrange(5)]) + bytes([1 if c else 0])
                continue
            if isinstance(c, (int, float)):
                s, ty = fmt_num(c), 0
            else:
                s, ty = (c if isinstance(c, str) else str(c)), 1
            raw = s.encode("utf-8")
            ai = algos[rng.randrange(len(algos))]
            e = ALGOS[ai](raw, sp, cid)
            out += bytes([ty]) + bytes([ai]) + vint(len(e)) + e
    return bytes(out)


def ser_proto_v131(p, idx_of, seed2, proto_idx0, perm_idx, rng):
    out = bytearray()
    out += u16(max(p.maxreg, 2))
    out += u16(p.nparam)
    out += u16(proto_idx0 + 1)      # VM 侧 §_pi§: 常量 cid 派生用
    out += u16(perm_idx)            # VM 侧 §_pmi§: 置换表共享池索引
    out += ser_const_pool_v131(p, seed2, proto_idx0, rng)
    out += u16(len(p.upvals))
    for (nm, kind, ix) in p.upvals:
        out += bytes([1 if kind == "reg" else 0]) + vint(ix + 1 if kind == "up" else ix)
    out += u32(len(p.code))
    for ins in p.code:
        out += bytes([ins[0]]) + vint(ins[1]) + vint(ins[2]) + vint(ins[3])
    jt = getattr(p, "jt", None) or {}
    out += u32(len(jt))
    for s_, pc_ in jt.items():
        out += vint(s_) + vint(pc_)
    out += u16(len(p.protos))
    for s in p.protos:
        out += vint(idx_of[id(s)])
    return bytes(out)


# ---------------- 自适应: 平坦化规模控制 ----------------
def flatten_adapt(root, rng, min_blocks, max_code, max_total):
    """只平坦化规模受控的 proto, 且新增指令总量封顶。"""
    tot_b = tot_i = 0
    stack = [root]
    while stack:
        P = stack.pop()
        if len(P.code) <= max_code and tot_i < max_total:
            r = flatten_proto(P, rng, min_blocks)
            if r:
                tot_b += r[0]
                tot_i += r[1]
        stack.extend(P.protos)
    return tot_b, tot_i


def build(src, seed=None, spread=5, dead=0.15, bulklm=512, meta=None, trace=False,
          flatten=True, min_blocks=3, lz=False):
    rng = random.Random(seed)
    c = Compiler()
    P = c.compile(src)

    protos0 = all_protos(P)
    n0 = sum(len(p.code) for p in protos0)

    # ---- 大文件自适应 ----
    max_code, max_flat_total = 10 ** 9, 10 ** 9
    if n0 > 40000:
        dead = min(dead, 0.05)
        min_blocks = max(min_blocks, 10)
        max_code = 1200
        max_flat_total = 9000
    elif n0 > 15000:
        dead = min(dead, 0.10)
        min_blocks = max(min_blocks, 6)
        max_code = 3000
        max_flat_total = 14000

    ndead = V13.inject_dead_v13(P, rng, dead, NOISE_OPS)
    patch(P)

    nflat_b = nflat_i = 0
    if flatten:
        nflat_b, nflat_i = flatten_adapt(P, rng, min_blocks, max_code, max_flat_total)

    order = []
    def walk(p):
        order.append(p)
        for s in p.protos:
            walk(s)
    walk(P)
    idx_of = {id(p): i for i, p in enumerate(order)}

    for p in all_protos(P):
        p._pool_used = const_usage(p)

    opmap, extra = V13.make_opmap13(rng, spread)
    seed1 = rng.randrange(1, 2147483646)
    seed2 = rng.randrange(1, 2147483646)

    # ---- C2: 置换/p2x 共享池 ----
    groups = []
    for _ in range(NPERM):
        perm = [0] * 256
        slots = list(range(256))
        rng.shuffle(slots)
        m = {}
        for op in ALL_OPS13:
            x = slots.pop()
            perm[x] = opmap[op]
            m[op] = x
        groups.append((perm, m))
    salt = rng.randrange(1, 1000003)
    assign = [(i * 7919 + salt) % NPERM for i in range(len(order))]

    for p in all_protos(P):
        for ins in p.code:
            for fi in KFIELDS.get(ins[0], ()):
                ins[fi] += 1
            for fi in PFIELDS.get(ins[0], ()):
                ins[fi] += 1
            for fi in UFIELDS.get(ins[0], ()):
                ins[fi] += 1

    body = bytearray()
    for pi, p in enumerate(order):
        old = p.code
        g = assign[pi]
        p2x = groups[g][1]
        p.code = [[p2x[ins[0]], ins[1], ins[2], ins[3]] for ins in old]
        try:
            body += ser_proto_v131(p, idx_of, seed2, pi, g + 1, rng)
        finally:
            p.code = old

    n = len(order)
    raw = (bytes([FMT_V]) + u16(NPERM)
           + b"".join(bytes(g[0]) for g in groups)
           + u16(n) + bytes(body))

    use_lz = False
    if lz and len(raw) > 120000:
        z = zlib.compress(raw, 9)
        if len(z) < len(raw) * 0.92:
            raw = bytes([FMT_V | 0x80]) + u32(len(z)) + z
            use_lz = True
    payload = raw

    enc = xor_all(payload, seed1)
    alpha = list(string.digits + string.ascii_letters + "!#$%&()*+-;<=>?@^_`{|}~")
    rng.shuffle(alpha)
    alpha = "".join(alpha[:85])
    data = b85_encode(enc, alpha)

    strs = []
    for p in all_protos(P):
        for k in p.consts:
            if isinstance(k, str) and 2 < len(k) < 64:
                strs.append(k)
    rng.shuffle(strs)
    decoy = strs[:24] or ["nil"]
    dl = ", ".join(lua_str(s, full=True) for s in decoy)

    tpl = open(os.path.join(HERE, "runtime_v131.tpl.lua")).read()
    tpl = strip_tpl_comments(tpl)
    tpl = tpl.replace("§ALPHA§", '"%s"' % alpha)
    tpl = tpl.replace("§SEED1§", str(seed1))
    tpl = tpl.replace("§SEED2§", str(seed2))
    tpl = tpl.replace("§RKBASE§", str(rng.randrange(1, 2147483646)))
    tpl = tpl.replace("§BULKLIM§", str(bulklm))
    tpl = tpl.replace("§DECOY§", "{%s}" % dl)
    tpl = tpl.replace("§HANDLERS§", V13.gen_handlers13(opmap, extra, rng))
    tpl = tpl.replace("§TRACE§", "")
    tpl = tpl.replace("§DATA§", "@DATA@")
    if meta is not None:
        meta.update(dict(opmap=opmap, extra=extra, seed2=seed2, ndead=ndead,
                         nproto=len(order), nperm=NPERM, lz=use_lz,
                         nflat_blocks=nflat_b, nflat_insns=nflat_i,
                         base_insns=n0, nnoise_op=len(NOISE_OPS), npool=NPOOL,
                         payload_bytes=len(payload)))
    tpl = mangle(tpl, rng)
    return tpl, data


def check(src, name="test", seed=None, spread=5, dead=0.12, norm=True, flatten=True):
    try:
        native = run_lua(src)
    except Exception as e:
        return False, "NATIVE FAIL %s" % str(e)[:200]
    try:
        tpl, data = build(src, seed=seed, spread=spread, dead=dead, flatten=flatten)
        code = tpl.replace("@DATA@", chunk_data(data, 3000))
        got = run_lua("return (function()\n%s\nend)()()" % code)
    except Exception as e:
        return False, "VM RUN FAIL: %s" % str(e)[:300]
    if norm:
        native, got = V13._norm(native), V13._norm(got)
    if native == got:
        return True, ""
    return False, "DIFF\n--nat--\n%s\n--obf--\n%s" % (native[:500], got[:500])


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("src")
    ap.add_argument("-o", "--out", required=True)
    ap.add_argument("--seed", type=int, default=None)
    ap.add_argument("--spread", type=int, default=5)
    ap.add_argument("--dead", type=float, default=0.15)
    a = ap.parse_args()
    src = open(a.src, encoding="utf-8").read()
    meta = {}
    tpl, data = build(src, seed=a.seed, spread=a.spread, dead=a.dead, meta=meta)
    code = tpl.replace("@DATA@", chunk_data(data, 3000))
    out = ("-- This file is protected by Luraph v1.3.1 special edition --\n"
           "(function() return (function()\n%s\nend)()() end)()" % code)
    open(a.out, "w", encoding="utf-8").write(out)
    print("OUT %s bytes=%d payload=%d lz=%s flat=%s/%s" % (
        a.out, len(out.encode()), meta.get("payload_bytes"), meta.get("lz"),
        meta.get("nflat_blocks"), meta.get("nflat_insns")))
