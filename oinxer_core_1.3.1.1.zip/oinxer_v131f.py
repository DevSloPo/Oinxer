#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Oinxer (Luraph Special Edition) v1.3.1 —— 完整双层封装 (体积压缩版)

L1 (内层) = oinxer_v13: 三常量池 b/e/C + 空操作 opcode 群 + 平坦化 + 每 proto
            独立置换 + 运行时二次编号
L0 (外层) = oinxer_v12: 运行时生成 base85 字符表 + 密钥由密文引导头自身哈希派生,
            整个 L1 运行时(含 handler 语义/常量解密算法) 加密成 base85 数据流,
            静态看不到任何 opcode 语义

输出固定 2 行: 首行英文 banner, 第二行全部代码糊在一起
"""
import sys, os, random
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import oinxer_v12 as V12
import oinxer_v131 as V13
from oinxer_v12 import build_l0, BOOTS, hash32

BANNER = "This file is protected by Luraph v1.3.1 special edition"


def build(src, seed=None, spread=5, dead=0.15, runnable=True,
          width=3000, boot=None, flatten=True, meta=None, lz=False):
    rng = random.Random(seed)
    # L1: v1.3.0 三池 VM 运行时 + payload
    tpl, data = V13.build(src, seed=seed, spread=spread, dead=dead,
                          flatten=flatten, meta=meta, lz=lz)
    l1_code = tpl.replace("@DATA@", V13.chunk_data(data, width))
    l1 = "return (function()\n%s\nend)()" % l1_code
    if runnable:
        l1 = l1 + "()"
    if boot is None:
        boot = BOOTS[rng.randrange(len(BOOTS))]
    l0, nchunk = build_l0(l1, boot, width, rng)
    if meta is not None:
        meta["boot"] = boot
        meta["l0_chunks"] = nchunk
        meta["l1_bytes"] = len(l1)
    return l0


def finalize(l0, banner=None, wrap=True):
    head = banner or BANNER
    if wrap:
        return "-- %s --\n(function() %s end)()" % (head, l0)
    return "-- %s --\n%s" % (head, l0)


def build_file(src, out, seed=None, spread=5, dead=0.15, runnable=True, lz=False):
    meta = {}
    l0 = build(src, seed=seed, spread=spread, dead=dead,
               runnable=runnable, meta=meta, lz=lz)
    out_txt = finalize(l0, wrap=runnable)
    open(out, "w", encoding="utf-8").write(out_txt)
    return out_txt, meta


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("src")
    ap.add_argument("-o", "--out", required=True)
    ap.add_argument("--seed", type=int, default=None)
    ap.add_argument("--spread", type=int, default=5)
    ap.add_argument("--dead", type=float, default=0.15)
    ap.add_argument("--pure", action="store_true", help="纯代码块版(供 loadstring/远程加载)")
    a = ap.parse_args()
    src = open(a.src, encoding="utf-8").read()
    txt, meta = build_file(src, a.out, seed=a.seed, spread=a.spread,
                           dead=a.dead, runnable=not a.pure)
    print("OUT %s bytes=%d lines=%d l1=%dB chunks=%d nproto=%s flat=%s/%s" % (
        a.out, len(txt.encode()), txt.count("\n") + 1, meta.get("l1_bytes", 0),
        meta.get("l0_chunks", 0), meta.get("nproto"),
        meta.get("nflat_blocks"), meta.get("nflat_insns")))


# ============================================================
# 回归测试接口 (与 testsuite.py 兼容)
# ============================================================
_POS = None
_ADDR = None

def _norm(s):
    global _POS, _ADDR
    import re
    if _POS is None:
        _POS = re.compile(r'(\[string "[^"]*"\]|\[string "<python>"\])(:\d+)?')
        _ADDR = re.compile(r'\b0x[0-9a-fA-F]+\b')
    return _ADDR.sub('0x?', _POS.sub('[string "?"]', s))


def check(src, name="test", seed=None, spread=5, dead=0.12, norm=True, **kw):
    from build import run_lua
    try:
        native = run_lua(src)
    except Exception as e:
        return False, "NATIVE FAIL %s" % str(e)[:200]
    try:
        l0 = build(src, seed=seed, spread=spread, dead=dead,
                   runnable=True, flatten=kw.get("flatten", True))
        got = run_lua(finalize(l0))
    except Exception as e:
        return False, "VM RUN FAIL: %s" % str(e)[:300]
    if norm:
        native, got = _norm(native), _norm(got)
    if native == got:
        return True, ""
    return False, "DIFF\n--nat--\n%s\n--obf--\n%s" % (native[:500], got[:500])
