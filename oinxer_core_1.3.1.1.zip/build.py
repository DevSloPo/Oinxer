#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Phoenix Obfuscator - 加密打包器
编译 -> 序列化 -> 常量加密 -> 整体XOR -> base85 -> 随机opcode分派 -> 填模板
"""
import sys, os, random, string
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from compiler import Compiler, patch, all_protos, Label
from build_ref import WRAP
try:
    from lupa import lua54
    _HAS_LUPA = True
except Exception:
    lua54 = None
    _HAS_LUPA = False

WRAP2 = r'''
_PHOENIX_OUT = {}
print = function(...)
  local t = {}
  for i = 1, select('#', ...) do t[i] = tostring((select(i, ...))) end
  _PHOENIX_OUT[#_PHOENIX_OUT+1] = table.concat(t, '\t')
end
%s
'''

def run_lua(src):
    if not _HAS_LUPA:
        raise RuntimeError("Lua runtime unavailable (lupa not installed)")
    L = lua54.LuaRuntime(unpack_returned_tuples=False)
    try:
        L.execute(WRAP2 % src)
    except Exception as e:
        raise RuntimeError("LUARUN %s" % str(e)[:400])
    t = L.eval("_PHOENIX_OUT")
    try:
        n = int(L.eval("#_PHOENIX_OUT"))
    except Exception:
        n = 0
    out = []
    for i in range(1, n + 1):
        try:
            out.append(str(t[i]))
        except Exception:
            out.append("?")
    return "\n".join(out)

HERE = os.path.dirname(os.path.abspath(__file__))

# ============================================================
# 1. 序列化
# ============================================================
def u16(v): return bytes([v & 0xFF, (v >> 8) & 0xFF])
def u32(v): return bytes([v & 0xFF, (v >> 8) & 0xFF, (v >> 16) & 0xFF, (v >> 24) & 0xFF])

def enc_bytes(data, seed2, cid):
    """复现模板 _dec 的 LCG 密钥流 (Lehmer 48271, 2^53 内安全)"""
    s = (seed2 + cid * 7919) % 2147483647
    out = bytearray()
    for b in data:
        s = (s * 48271) % 2147483647
        out.append(b ^ (s % 256))
    return bytes(out)

INF = float("inf")
def fmt_num(c):
    """保留 Lua 整数/浮点子类型: 浮点必须带 . 或 e"""
    if isinstance(c, bool):
        return "true" if c else "false"
    if isinstance(c, int):
        return str(c)
    if c != c:
        return "0/0"
    if c == INF:
        return "1e999"
    if c == -INF:
        return "-1e999"
    s = repr(c)
    if ("." not in s) and ("e" not in s) and ("n" not in s):
        s += ".0"
    return s

def ser_const_pool(P, seed2, cid_counter):
    """返回常量池加密字节块"""
    out = bytearray()
    out += u16(len(P.consts))
    for c in P.consts:
        cid = next(cid_counter)
        if isinstance(c, bool):
            out += bytes([2]) + u32(cid) + bytes([1 if c else 0])
        else:
            if isinstance(c, (int, float)):
                s = fmt_num(c)
                ty = 0
            else:
                s = c if isinstance(c, str) else str(c)
                ty = 1
            raw = s.encode("utf-8")
            e = enc_bytes(raw, seed2, cid)
            out += bytes([ty]) + u32(cid) + u16(len(e)) + e
    return bytes(out)

def ser_proto(P, idx_of, seed2, cid_counter, key=(1, 0, 1)):
    out = bytearray()
    out += u16(max(P.maxreg, 2))
    out += u16(P.nparam)
    # per-proto 仿射编号密钥 (A, B, A^-1)
    out += u16(key[0]) + u16(key[1]) + u16(key[2])
    out += ser_const_pool(P, seed2, cid_counter)
    # upvalues
    out += u16(len(P.upvals))
    for (nm, kind, ix) in P.upvals:
        kd = 1 if kind == "reg" else 0
        # 父级 upvalue 索引 0-based -> 1-based (Lua 表)
        out += bytes([kd]) + u16(ix + 1 if kind == "up" else ix)
    # code
    out += u32(len(P.code))
    for ins in P.code:
        out += bytes([ins[0]]) + u16(ins[1]) + u16(ins[2]) + u16(ins[3])
    # subs
    out += u16(len(P.protos))
    for s in P.protos:
        out += u32(idx_of[id(s)])
    return bytes(out)

def serialize(root, opmap, seed2, cid_counter, extra=None, keys=None, rng=None):
    order = []
    def walk(P):
        order.append(P)
        for s in P.protos:
            walk(s)
    walk(root)
    idx_of = {}
    for i, P in enumerate(order):
        idx_of[id(P)] = i
    out = bytearray()
    out += u16(len(order))
    used_bytes = set()
    for pi, P in enumerate(order):
        key = keys[pi] if keys else (1, 0, 1)
        A, B, _ = key
        mapped = []
        for ins in P.code:
            x = pick_num(ins[0], opmap, extra or {}, rng) if rng else opmap[ins[0]]
            y = (x * A + B) % 256
            used_bytes.add(y)
            mapped.append([y, ins[1], ins[2], ins[3]])
        old = P.code
        P.code = mapped
        try:
            out += ser_proto(P, idx_of, seed2, cid_counter, key)
        finally:
            P.code = old
    return bytes(out), used_bytes


def inject_dead(root, rng, density=0.10):
    """注入不可达语义的死指令。
       关键: 必须在 patch() 之前调用, 但插入会整体平移指令下标,
       因此要同步修正所有 Label.pos, 否则跳转目标会指错。"""
    n = 0
    for P in all_protos(root):
        out, mapping = [], {}
        for idx, ins in enumerate(P.code):
            mapping[idx] = len(out)
            out.append(ins)
            if rng.random() < density:
                out.append(["DEAD", rng.randrange(0, 256), rng.randrange(0, 256),
                            rng.randrange(0, 256)])
                n += 1
        mapping[len(P.code)] = len(out)
        # 先快照原始位置再统一修正: 同一 Label 被多处引用时若逐个就地修改,
        # 第二次会用已修正过的值再查一次表 -> 二次偏移, 跳转目标整体错位。
        labels = {}
        for ins in P.code:
            for i in range(1, 4):
                if isinstance(ins[i], Label):
                    labels[id(ins[i])] = (ins[i], ins[i].pos)
        for lb, oldpos in labels.values():
            lb.pos = mapping.get(oldpos, oldpos)
        P.code = out
    return n


def pick_num(op, opmap, extra, rng):
    alts = extra.get(op)
    if alts and rng.random() < 0.45:
        return rng.choice(alts)
    return opmap[op]


def modinv(a, m=256):
    """a 必须为奇数; 返回 a^-1 mod 256"""
    for i in range(1, m):
        if (a * i) % m == 1:
            return i
    raise ValueError(a)


def make_proto_keys(n, rng):
    """每个 proto 一套仿射编号变换: 字节码 Y = (分派编号 X * A + B) mod 256
       A 取奇数保证是 Z_256 上的双射, 故永不碰撞; 运行时用 A^-1 还原。
       同一语义在不同函数里字节码编号不同 -> 无法靠一张 opcode 表通解。"""
    keys = []
    for _ in range(n):
        a = rng.randrange(1, 256) | 1          # 奇数
        b = rng.randrange(0, 256)
        keys.append((a, b, modinv(a)))
    return keys


def gen_map_table(used_bytes, rng):
    """诱饵表: 键必须避开所有真实字节码编号, 否则会把指令解码错。"""
    items = []
    for _ in range(80):
        k = rng.randrange(1, 256)
        if k in used_bytes:
            continue
        items.append("[%d]=%d" % (k, rng.randrange(256, 400)))
    rng.shuffle(items)
    return "{" + ",".join(items) + "}"


# ============================================================
# 2. base85 + XOR
# ============================================================
def b85_encode(data, alpha):
    out = []
    n = len(data)
    i = 0
    while i < n:
        chunk = list(data[i:i + 4])
        while len(chunk) < 4:
            chunk.append(0)
        acc = (chunk[0] << 24) | (chunk[1] << 16) | (chunk[2] << 8) | chunk[3]
        d = []
        for _ in range(5):
            d.append(acc % 85)
            acc //= 85
        d.reverse()
        out.append("".join(alpha[x] for x in d))
        i += 4
    return "".join(out)

def xor_all(data, seed1):
    s = seed1
    out = bytearray()
    for b in data:
        s = (s * 48271) % 2147483647
        out.append(b ^ (s % 256))
    return bytes(out)

# ============================================================
# 3. opcode 随机编号 (核心抗逆向: 每次构建不同)
# ============================================================
ALL_OPS = ["ADD","BOX","CALL","CALLM","CLOSURE","CLOSUREB","CONCAT","DIV","EQ","FDIV",
           "GETBOX","GETFIELD","GETGLOBAL","GETTABLE","GETUPVAL","JMP","JMPIF","JMPIFNOT",
           "LE","LEN","LOADBOOL","LOADK","LOADNIL","LT","MOD","MOVE","MUL","NE","NEWTABLE",
           "NOT","POW","RETURN","RETURNM","SETBOX","SETFIELD","SETGLOBAL","SETLIST",
           "SETLISTM","SETTABLE","SETUPVAL","SUB","UNM","VARARG","VARARGM","DEAD",
           "JMPIND"]

def make_opmap(rng, spread=1):
    """为每个操作码分配随机编号; spread>1 时一个语义占多个编号(多态)"""
    slots = list(range(1, 256))
    rng.shuffle(slots)
    opmap = {}
    i = 0
    for op in ALL_OPS:
        opmap[op] = slots[i]
        i += 1
    # 多态: 给高频指令额外分配别名编号
    extra = {}
    if spread > 1:
        hot = ["MOVE","LOADK","GETFIELD","GETGLOBAL","SETTABLE","GETTABLE","SETFIELD","ADD","EQ","JMPIFNOT"]
        for op in hot:
            for _ in range(spread - 1):
                if i >= len(slots):
                    break
                extra.setdefault(op, []).append(slots[i])
                i += 1
    return opmap, extra

# ============================================================
# 4. 分派代码生成
# ============================================================
DISPATCH = {
 "LOADK":    "§_R§[§_A§] = §_K§[§_B§]",
 "LOADNIL":  "§_R§[§_A§] = nil",
 "LOADBOOL": "§_R§[§_A§] = (§_B§ == 1)",
 "MOVE":     "§_R§[§_A§] = §_R§[§_B§]",
 "BOX":      "§_R§[§_A§] = {[1] = §_R§[§_A§]}",
 "GETBOX":   "§_R§[§_A§] = §_R§[§_B§][1]",
 "SETBOX":   "§_R§[§_A§][1] = §_R§[§_B§]",
 "GETGLOBAL":"§_R§[§_A§] = §_G§[§_K§[§_B§]]",
 "SETGLOBAL":"§_G§[§_K§[§_B§]] = §_R§[§_A§]",
 "GETUPVAL": "§_R§[§_A§] = §_U§[§_B§][1]",
 "SETUPVAL": "§_U§[§_B§][1] = §_R§[§_A§]",
 "GETTABLE": "§_R§[§_A§] = §_R§[§_B§][§_R§[§_C§]]",
 "SETTABLE": "§_R§[§_A§][§_R§[§_B§]] = §_R§[§_C§]",
 "GETFIELD": "§_R§[§_A§] = §_R§[§_B§][§_K§[§_C§]]",
 "SETFIELD": "§_R§[§_A§][§_K§[§_B§]] = §_R§[§_C§]",
 "NEWTABLE": "§_R§[§_A§] = {}",
 "SETLIST":  "§_R§[§_A§][§_B§] = §_R§[§_C§]",
 "SETLISTM": "do local §_j§ = 0 while §_B§ + §_j§ <= §_TOP§ do §_R§[§_A§][§_B§ + §_j§] = §_R§[§_C§ + §_j§]; §_j§ = §_j§ + 1 end end",
 "JMP":      "§_n§ = §_B§",
 "JMPIF":    "local §_v§ = §_R§[§_A§] if §_v§ ~= nil and §_v§ ~= false then §_n§ = §_B§ end",
 "JMPIFNOT": "local §_v§ = §_R§[§_A§] if §_v§ == nil or §_v§ == false then §_n§ = §_B§ end",
 # 平坦化调度: O(1) 跳转表。v1.2.0 的线性 if 链对大 proto (数百块) 每次块转移
 # 要扫 3*nb/2 条指令, DOORS 最大 proto 529 块 -> 约 794 条/次, 直接卡死
 "JMPIND":   "do local §_t§ = §_JT§[§_R§[§_A§]] if §_t§ then §_n§ = §_t§ else §_n§ = §_CL§ + 1 end end",
 "ADD":  "§_R§[§_A§] = §_R§[§_B§] + §_R§[§_C§]",
 "SUB":  "§_R§[§_A§] = §_R§[§_B§] - §_R§[§_C§]",
 "MUL":  "§_R§[§_A§] = §_R§[§_B§] * §_R§[§_C§]",
 "DIV":  "§_R§[§_A§] = §_R§[§_B§] / §_R§[§_C§]",
 "MOD":  "§_R§[§_A§] = §_R§[§_B§] % §_R§[§_C§]",
 "FDIV": "§_R§[§_A§] = §_floor§(§_R§[§_B§] / §_R§[§_C§])",
 "POW":  "§_R§[§_A§] = §_R§[§_B§] ^ §_R§[§_C§]",
 "UNM":  "§_R§[§_A§] = -§_R§[§_B§]",
 "NOT":  "§_R§[§_A§] = not §_R§[§_B§]",
 "LEN":  "§_R§[§_A§] = #§_R§[§_B§]",
 "CONCAT":"§_R§[§_A§] = §_R§[§_B§] .. §_R§[§_C§]",
 "EQ":   "§_R§[§_A§] = (§_R§[§_B§] == §_R§[§_C§])",
 "NE":   "§_R§[§_A§] = (§_R§[§_B§] ~= §_R§[§_C§])",
 "LT":   "§_R§[§_A§] = (§_R§[§_B§] < §_R§[§_C§])",
 "LE":   "§_R§[§_A§] = (§_R§[§_B§] <= §_R§[§_C§])",
 "DEAD": "do end",
 "RETURN": """do local §_nn§ = §_B§ - 1
      local §_o§ = {}; §_o§[0] = §_nn§
      for §_i§ = 1, §_nn§ do §_o§[§_i§] = §_R§[§_A§ + §_i§ - 1] end
      return §_o§ end""",
 "RETURNM": """do local §_nn§ = §_TOP§ - §_A§ + 1
      if §_nn§ < 0 then §_nn§ = 0 end
      local §_o§ = {}; §_o§[0] = §_nn§
      for §_i§ = 1, §_nn§ do §_o§[§_i§] = §_R§[§_A§ + §_i§ - 1] end
      return §_o§ end""",
 "VARARG": """do local §_nn§ = §_B§ - 1
      for §_i§ = 1, §_nn§ do §_R§[§_A§ + §_i§ - 1] = §_args§[§_i§] end end""",
 "VARARGM": """do local §_nn§ = §_na§
      for §_i§ = 1, §_nn§ do §_R§[§_A§ + §_i§ - 1] = §_args§[§_i§] end
      §_TOP§ = §_A§ + §_nn§ - 1 end""",
 "CALL": """do local §_f§ = §_R§[§_A§]
      local §_ng§ = (§_B§ == 0) and (§_TOP§ - §_A§) or (§_B§ - 1)
      local §_aa§ = {}
      for §_i§ = 1, §_ng§ do §_aa§[§_i§] = §_R§[§_A§ + §_i§] end
      §_aa§[0] = §_ng§
      local §_rs§
      local §_in§ = (§_type§(§_f§) == "function") and §_REG§[§_f§] or nil
      if §_in§ then §_rs§ = §_interp§(§_in§[1], §_in§[2], §_aa§, §_G§)
      else §_rs§ = §_pack§(§_f§(§_upk§(§_aa§, 1, §_ng§))) end
      local §_nr§ = §_rs§[0] or #§_rs§
      local §_wn§ = (§_o§ == §OC_CALLM§) and §_nr§ or (§_C§ - 1)
      for §_i§ = 1, §_wn§ do §_R§[§_A§ + §_i§ - 1] = §_rs§[§_i§] end
      §_TOP§ = §_A§ + §_nr§ - 1 end""",
 "CLOSURE": """do local §_sp§ = §_SUB§[§_B§]
      local §_u§ = {}
      local §_uv§ = §_sp§[3]
      for §_i§ = 1, #§_uv§ do
        local §_d§ = §_uv§[§_i§]
        if §_d§[1] == 1 then §_u§[§_i§] = §_R§[§_d§[2]] else §_u§[§_i§] = §_U§[§_d§[2]] end
      end
      local §_f§ = §_mk§(§_sp§, §_u§)
      §_R§[§_A§] = §_f§ end""",
 "CLOSUREB": """do local §_sp§ = §_SUB§[§_B§]
      local §_u§ = {}
      local §_uv§ = §_sp§[3]
      for §_i§ = 1, #§_uv§ do
        local §_d§ = §_uv§[§_i§]
        if §_d§[1] == 1 then §_u§[§_i§] = §_R§[§_d§[2]] else §_u§[§_i§] = §_U§[§_d§[2]] end
      end
      local §_f§ = §_mk§(§_sp§, §_u§)
      §_R§[§_A§][1] = §_f§ end""",
}

# 需要常量索引 +1 (0-based -> 1-based) 的字段
KFIELDS = {"LOADK": (2,), "GETGLOBAL": (2,), "SETGLOBAL": (2,),
           "GETFIELD": (3,), "SETFIELD": (2,)}
PFIELDS = {"CLOSURE": (2,), "CLOSUREB": (2,)}
UFIELDS = {"GETUPVAL": (2,), "SETUPVAL": (2,)}

def gen_dispatch(opmap, extra, rng):
    entries = []  # (编号, 代码)
    for op, num in opmap.items():
        body = DISPATCH.get(op)
        if body is None:
            # CALLM 与 CALL 共用实现 (内部按 opcode 编号区分)
            if op == "CALLM":
                body = DISPATCH["CALL"]
            else:
                continue
        entries.append((num, body))
    for op, nums in extra.items():
        for n in nums:
            entries.append((n, DISPATCH[op]))
    rng.shuffle(entries)
    lines = []
    first = True
    for num, body in entries:
        kw = "if" if first else "elseif"
        first = False
        lines.append("    %s §_o§ == %d then %s" % (kw, num, body))
    lines.append("    end")
    txt = "\n".join(lines)
    txt = txt.replace("§OC_CALLM§", str(opmap["CALLM"]))
    return txt

# ============================================================
# 5. 主流程
# ============================================================
LUA_KW = set("""and break do else elseif end false for function goto if in local nil
not or repeat return then true until while""".split())

def strip_tpl_comments(tpl):
    """剔除运行时模板里的整行注释 (在 payload 注入之前调用, 故不会误伤密文中的 '--')"""
    out = []
    for ln in tpl.split("\n"):
        st = ln.strip()
        if st.startswith("--"):
            continue
        out.append(ln)
    return "\n".join(out)


def mangle(tpl, rng):
    """把模板里剩余的 §xxx§ 占位符替换成随机合法标识符"""
    import re
    names = {}
    used = set(LUA_KW)
    def nm(m):
        key = m.group(0)
        if key not in names:
            while True:
                n = "_" + "".join(rng.choice(string.ascii_letters + string.digits)
                                  for _ in range(rng.randint(5, 13)))
                if n not in used:
                    break
            used.add(n)
            names[key] = n
        return names[key]
    return re.sub(r"§[A-Za-z_][A-Za-z0-9_]*§", nm, tpl)


def build(src, seed=None, spread=1, dead=0.0, debug=None, meta=None, trace=False):
    rng = random.Random(seed)
    c = Compiler()
    P = c.compile(src)
    ndead = inject_dead(P, rng, dead)
    patch(P)

    seed1 = rng.randrange(1, 2147483646)
    seed2 = rng.randrange(1, 2147483646)
    opmap, extra = make_opmap(rng, spread)
    nproto = len(all_protos(P))
    keys = make_proto_keys(nproto, rng)

    # 常量索引 +1 修正 (Python 0-based -> Lua 1-based)
    for p in all_protos(P):
        for ins in p.code:
            for fi in KFIELDS.get(ins[0], ()):
                ins[fi] += 1
            for fi in PFIELDS.get(ins[0], ()):
                ins[fi] += 1
            for fi in UFIELDS.get(ins[0], ()):
                ins[fi] += 1

    counter = iter(range(1, 10 ** 9))
    raw, used_bytes = serialize(P, opmap, seed2, counter, extra, keys, rng)
    enc = xor_all(raw, seed1)
    alpha = list(string.digits + string.ascii_letters + "!#$%&()*+-;<=>?@^_`{|}~")
    rng.shuffle(alpha)
    alpha = "".join(alpha[:85])
    data = b85_encode(enc, alpha)

    tpl = open(os.path.join(HERE, "runtime.tpl.lua")).read()
    tpl = strip_tpl_comments(tpl)
    tpl = tpl.replace("§ALPHA§", '"%s"' % alpha)
    tpl = tpl.replace("§SEED1§", str(seed1))
    tpl = tpl.replace("§SEED2§", str(seed2))
    tpl = tpl.replace("§DATA§", '"%s"' % data)
    disp = gen_dispatch(opmap, extra, rng)
    if meta is not None:
        meta.update(dict(opmap=opmap, extra=extra, seed1=seed1, seed2=seed2,
                         alpha=alpha, nbytes=len(raw), ndead=ndead,
                         nproto=nproto, perproto=True))
    if debug:
        tpl = tpl.replace('local §_REG§ = §_setm§({}, {__mode = "k"})',
                          'local §_REG§ = §_setm§({}, {__mode = "k"})\nlocal §_DC§ = 0')
        disp = ("§_DC§ = §_DC§ + 1\n    if §_DC§ > %d then "
                "error('LOOPGUARD pc=' .. §_pc§ .. ' op=' .. tostring(§_o§)) end\n"
                % debug) + disp
    tpl = tpl.replace("§_MAP§ = {}", "§_MAP§ = %s" % gen_map_table(used_bytes, rng))
    tpl = tpl.replace("§DISPATCH§", disp)
    tr = ""
    if trace:
        tr = ("if _PTRACE then _PTRACE[#_PTRACE+1] = §_o§ .. \",\" .. §_A§ .. \",\" .. §_B§ .. \",\" .. §_C§ end")
    tpl = tpl.replace("§TRACE§", tr)
    return mangle(tpl, rng)


def check(src, name="test", seed=None):
    try:
        vm = build(src, seed)
    except Exception as e:
        import traceback
        return False, "BUILD FAIL: %s\n%s" % (str(e)[:300], traceback.format_exc()[-800:])
    try:
        got = run_lua("local run = (function()\n%s\nend)()\nrun()" % vm)
    except Exception as e:
        return False, "VM RUN FAIL: %s" % str(e)[:500]
    try:
        want = run_lua(src)
    except Exception as e:
        return False, "NATIVE FAIL: %s" % str(e)[:300]
    import re as _re
    norm = lambda s: _re.sub(r'\]:\d+:', ']:L:', s)
    if norm(got) == norm(want):
        return True, "OK (%d lines)" % (got.count("\n") + 1)
    return False, "MISMATCH\n--want--\n%s\n--got--\n%s" % (want[:600], got[:600])


if __name__ == "__main__":
    f = sys.argv[1] if len(sys.argv) > 1 else "/data/workspace/obf/t1.lua"
    src = open(f).read()
    ok, msg = check(src, f)
    print("[%s] %s" % ("PASS" if ok else "FAIL", msg))
