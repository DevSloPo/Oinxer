#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Oinxer Obfuscator (Luraph Special Edition) v1.1.0

v1.0.0 的四个缺陷 -> v1.1.0 对策
  1. 常量加密可逆且算法明文  -> 5 种随机算法 + 诱饵池 + 反批量遍历
  2. VM 明码 if/elseif 分派  -> handler 闭包数组, 无明文 opcode 语义表
  3. opcode 仿射可逆         -> 每 proto 独立随机置换表(非算术) + 运行时二次编号
  4. 无对抗层                -> 反 hook / 反 dump / 篡改静默降级 / 环境指纹

附带修复
  - 卡死: 256 分支 if/elseif 链 -> O(1) 数组分派 (性能数量级提升)
  - GitHub 上传: payload 分块为多行字符串拼接, 纯 ASCII 无超长行
"""
import sys, os, random, string
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from compiler import Compiler, patch, all_protos, Label
from flatten import flatten_all
from build import run_lua, fmt_num, DISPATCH, ALL_OPS, KFIELDS, PFIELDS, UFIELDS, \
    make_opmap, inject_dead, xor_all, b85_encode, strip_tpl_comments, LUA_KW

HERE = os.path.dirname(os.path.abspath(__file__))

def u16(v): return bytes([v & 0xFF, (v >> 8) & 0xFF])
def u32(v): return bytes([v & 0xFF, (v >> 8) & 0xFF, (v >> 16) & 0xFF, (v >> 24) & 0xFF])


# ============================================================
# 常量加密: 5 种算法 (构建期加密 = 运行期解密的逆)
# ============================================================
def _xor(a, b):
    r, m = 0, 1
    while a > 0 or b > 0:
        x, y = a % 2, b % 2
        if x != y:
            r += m
        a, b = (a - x) // 2, (b - y) // 2
        m *= 2
    return r

def _sd(seed2, cid):
    return (seed2 + cid * 104729) % 2147483647

def algo1(plain, seed2, cid):        # LCG 流 XOR (自逆)
    s = (_sd(seed2, cid) + cid * 7919) % 2147483647
    out = bytearray()
    for b in plain:
        s = (s * 48271) % 2147483647
        out.append(b ^ (s % 256))
    return bytes(out)

def algo2(plain, seed2, cid):        # 加法链
    k = (_sd(seed2, cid) + cid * 5407) % 251
    return bytes([(b - k - (i + 1) * 13) % 256 for i, b in enumerate(plain)])

def algo3(plain, seed2, cid):        # 双向 XOR (自逆)
    k = (_sd(seed2, cid) + cid * 3301) % 256
    n = len(plain)
    return bytes([b ^ (k ^ ((n - i) % 256)) for i, b in enumerate(plain)])

def algo4(plain, seed2, cid):        # 重排后减
    k = (_sd(seed2, cid) + cid * 6151) % 256
    n = len(plain)
    return bytes([(plain[n - 1 - j] + k + (n - j)) % 256 for j in range(n)])

def algo5(plain, seed2, cid):        # 累积链
    k = (_sd(seed2, cid) + cid * 7919) % 256
    prev = k
    out = bytearray()
    for b in plain:
        out.append((_xor(b, k) - prev) % 256)
        prev = b
    return bytes(out)

ALGOS = [algo1, algo2, algo3, algo4, algo5]


# ============================================================
# 序列化 v1.1.0
# ============================================================
def ser_const_pool_v11(P, seed2, cid_counter, rng):
    out = bytearray()
    out += u16(len(P.consts))
    for c in P.consts:
        cid = next(cid_counter)
        if isinstance(c, bool):
            out += bytes([2]) + u32(cid) + bytes([rng.randrange(5)]) + bytes([1 if c else 0])
            continue
        if isinstance(c, (int, float)):
            s, ty = fmt_num(c), 0
        else:
            s, ty = (c if isinstance(c, str) else str(c)), 1
        raw = s.encode("utf-8")
        ai = rng.randrange(5)
        e = ALGOS[ai](raw, seed2, cid)
        # v1.2.1: 长度 u16 -> u32。u16 上限 65535, 更长的常量会把长度截断,
        # 解析时整条 proto 后续字段全部错位 (静默损坏, 不报错)
        out += bytes([ty]) + u32(cid) + bytes([ai]) + u32(len(e)) + e
    return bytes(out)

def ser_proto_v11(P, idx_of, seed2, cid_counter, perm_idx, rng):
    out = bytearray()
    out += u16(max(P.maxreg, 2))
    out += u16(P.nparam)
    out += u16(perm_idx)
    out += ser_const_pool_v11(P, seed2, cid_counter, rng)
    out += u16(len(P.upvals))
    for (nm, kind, ix) in P.upvals:
        out += bytes([1 if kind == "reg" else 0]) + u16(ix + 1 if kind == "up" else ix)
    out += u32(len(P.code))
    for ins in P.code:
        out += bytes([ins[0]]) + u16(ins[1]) + u16(ins[2]) + u16(ins[3])
    # 平坦化跳转表: 状态值 -> 块首 pc
    jt = getattr(P, "jt", None) or {}
    out += u32(len(jt))
    for s_, pc_ in jt.items():
        out += u32(s_) + u32(pc_)
    out += u16(len(P.protos))
    for s in P.protos:
        out += u32(idx_of[id(s)])
    return bytes(out)


# ============================================================
# handler 闭包数组生成 (O(1) 分派)
# ============================================================
def _fix(body, op, opmap):
    b = body
    if op in ("RETURN", "RETURNM"):
        b = b.replace("return §_o§ end", "§_RES§ = §_o§ end")
    if op in ("VARARG", "VARARGM"):
        b = b.replace("§_args§", "§_ARGS§").replace("§_na§", "§_NA§")
    if op == "CALL":
        b = b.replace("(§_o§ == §OC_CALLM§) and §_nr§ or (§_C§ - 1)", "(§_C§ - 1)")
    if op == "CALLM":
        b = DISPATCH["CALL"].replace("(§_o§ == §OC_CALLM§) and §_nr§ or (§_C§ - 1)", "§_nr§")
        b = b.replace("§_args§", "§_ARGS§").replace("§_na§", "§_NA§")
    return b

def gen_handlers(opmap, extra, rng):
    items = []
    for op, num in opmap.items():
        body = DISPATCH.get(op)
        if body is None:
            # CALLM 与 CALL 共用实现, 但必须独立生成一份 (否则多返回值调用会被静默跳过)
            if op == "CALLM":
                body = DISPATCH["CALL"]
            else:
                continue
        items.append((num, _fix(body, op, opmap)))
    for op, nums in (extra or {}).items():
        for n in nums:
            items.append((n, _fix(DISPATCH[op], op, opmap)))
    rng.shuffle(items)
    return "\n".join("§_H§[%d] = function() %s end" % (n, b) for n, b in items)


# ============================================================
# 主构建
# ============================================================
def build(src, seed=None, spread=1, dead=0.0, bulklm=512, meta=None, trace=False,
          flatten=True, min_blocks=3):
    rng = random.Random(seed)
    c = Compiler()
    P = c.compile(src)
    ndead = inject_dead(P, rng, dead)
    patch(P)

    # 控制流平坦化: 必须在 patch(跳转位置解析)之后, 常量索引 +1 之前
    nflat_b = nflat_i = 0
    if flatten:
        nflat_b, nflat_i = flatten_all(P, rng, min_blocks)

    protos = all_protos(P)
    order = []
    def walk(p):
        order.append(p)
        for s in p.protos:
            walk(s)
    walk(P)
    idx_of = {id(p): i for i, p in enumerate(order)}

    seed1 = rng.randrange(1, 2147483646)
    seed2 = rng.randrange(1, 2147483646)
    opmap, extra = make_opmap(rng, spread)

    # 每 proto 独立随机置换表 (非算术, 无逆可求)
    perms, p2x = [], []
    for p in order:
        perm = [0] * 256
        slots = list(range(256))
        rng.shuffle(slots)
        m = {}
        for op in ALL_OPS:
            x = slots.pop()
            perm[x] = opmap[op]
            m[op] = x
        perms.append(perm)
        p2x.append(m)

    # 常量索引 +1 (0-based -> 1-based)
    for p in protos:
        for ins in p.code:
            for fi in KFIELDS.get(ins[0], ()):
                ins[fi] += 1
            for fi in PFIELDS.get(ins[0], ()):
                ins[fi] += 1
            for fi in UFIELDS.get(ins[0], ()):
                ins[fi] += 1

    # 序列化 (指令 opcode 字节 = 该 proto 置换后的值)
    cid_counter = iter(range(1, 10 ** 9))
    body = bytearray()
    for pi, p in enumerate(order):
        old = p.code
        p.code = [[p2x[pi][ins[0]], ins[1], ins[2], ins[3]] for ins in old]
        try:
            body += ser_proto_v11(p, idx_of, seed2, cid_counter, pi + 1, rng)
        finally:
            p.code = old
    # payload: [版本][proto数][置换表][proto数(供 _parse 读取)][protos...]
    n = len(order)
    payload = (bytes([2]) + u16(n) + bytes(b for perm in perms for b in perm)
               + u16(n) + bytes(body))

    enc = xor_all(payload, seed1)
    alpha = list(string.digits + string.ascii_letters + "!#$%&()*+-;<=>?@^_`{|}~")
    rng.shuffle(alpha)
    alpha = "".join(alpha[:85])
    data = b85_encode(enc, alpha)

    # 诱饵池: 采样真实字符串后打乱, 被分析时返回错位内容
    strs = []
    for p in protos:
        for k in p.consts:
            if isinstance(k, str) and 2 < len(k) < 64:
                strs.append(k)
    rng.shuffle(strs)
    decoy = strs[:24] or ["nil"]
    dl = ", ".join(lua_str(s, full=True) for s in decoy)

    tpl = open(os.path.join(HERE, "runtime_v11.tpl.lua")).read()
    tpl = strip_tpl_comments(tpl)
    tpl = tpl.replace("§ALPHA§", '"%s"' % alpha)
    tpl = tpl.replace("§SEED1§", str(seed1))
    tpl = tpl.replace("§SEED2§", str(seed2))
    tpl = tpl.replace("§RKBASE§", str(rng.randrange(1, 2147483646)))
    tpl = tpl.replace("§BULKLIM§", str(bulklm))
    tpl = tpl.replace("§DECOY§", "{%s}" % dl)
    tpl = tpl.replace("§HANDLERS§", gen_handlers(opmap, extra, rng))
    tr = ""
    if trace:
        tr = 'if _PTRACE then _PTRACE[#_PTRACE+1] = §_pc§ .. "|" .. §_i§[1] .. "|" .. tostring(§_R§[2]) .. "," .. tostring(§_R§[3]) .. "," .. tostring(§_R§[4]) .. "," .. tostring(§_R§[7]) .. "," .. tostring(§_R§[9]) end'
    tpl = tpl.replace("§TRACE§", tr)
    tpl = tpl.replace("§DATA§", "@DATA@")
    if meta is not None:
        meta.update(dict(opmap=opmap, extra=extra, p2x=p2x, seed2=seed2, ndead=ndead,
                         nproto=len(order), perms=perms,
                         nflat_blocks=nflat_b, nflat_insns=nflat_i))

    tpl = mangle(tpl, rng)
    return tpl, data

def lua_str(s, full=False):
    """字符串字面量: 非 ASCII 转成 \\ddd 字节转义, 避免源码中文以明文出现。
       full=True 时对所有字节转义 (诱饵池专用: 诱饵采样自源码真实字符串,
       若以明文写入产物就等于把源码字符串泄漏出去)"""
    out = []
    if full:
        for b in s.encode("utf-8"):
            out.append("\\%03d" % b)
        return '"%s"' % "".join(out)
    for ch in s:
        o = ord(ch)
        if ch == "\\":
            out.append("\\\\")
        elif ch == '"':
            out.append('\\"')
        elif ch == "\n":
            out.append("\\n")
        elif ch == "\r":
            out.append("\\r")
        elif ch == "\t":
            out.append("\\t")
        elif 32 <= o < 127:
            out.append(ch)
        else:
            for b in ch.encode("utf-8"):
                out.append("\\%03d" % b)
    return '"%s"' % "".join(out)

def mangle(tpl, rng):
    import re
    names, used = {}, set(LUA_KW)
    def nm(m):
        key = m.group(0)
        if key not in names:
            while True:
                n = "_" + "".join(rng.choice(string.ascii_letters + string.digits)
                                  for _ in range(rng.randint(5, 13)))
                if n not in used:
                    break
            used.add(n)
            names[key] = n
        return names[key]
    return re.sub(r"§[A-Za-z_][A-Za-z0-9_]*§", nm, tpl)

def chunk_data(data, width=3000):
    """把巨大的 base85 串切成多段。
       注意: 不能用 "a" .. "b" .. "c" ... 的长链拼接 —— 上千段的 .. 链会让
       Lua 解析器递归过深直接 C stack overflow。改成逐条赋值 + table.concat,
       每行一条语句, 既避免超长行(GitHub 上传)又避免解析栈溢出。"""
    parts = [data[i:i + width] for i in range(0, len(data), width)]
    out = ["(function() local _t={}"]
    for p in parts:
        out.append('_t[#_t+1]="' + p + '"')
    out.append("return table.concat(_t) end)()")
    return "\n".join(out)

def finalize(tpl, data, banner=None, width=3000, runnable=False, oneline_head=True):
    head = banner or "This file is protected by Luraph v1.2.1 special edition"
    joined = chunk_data(data, width)
    code = tpl.replace("@DATA@", joined)
    body = "(function()\n%s\nend)()" % code
    if runnable:
        body = body + "()"
    out = "-- %s --\n%s" % (head, body)
    return out


_POSRE = None
def _norm(s):
    """归一化 VM 内部位置信息 (错误信息行号/地址), 只保留消息文本"""
    global _POSRE
    if _POSRE is None:
        import re
        _POSRE = (re.compile(r'(\[string "[^"]*"\]):\d+'),
                  re.compile(r'\b0x[0-9a-fA-F]+\b'))
    s = _POSRE[0].sub(r'\1:?', s)
    s = _POSRE[1].sub('0x?', s)
    return s

def check(src, name="test", seed=None, norm=False, **kw):
    try:
        tpl, data = build(src, seed=seed, **kw)
        vm = finalize(tpl, data, runnable=True)
    except Exception as e:
        import traceback
        return False, "BUILD FAIL: %s\n%s" % (str(e)[:300], traceback.format_exc()[-600:])
    try:
        got = run_lua(vm)
    except Exception as e:
        return False, "VM RUN FAIL: %s" % str(e)[:400]
    try:
        want = run_lua(src)
    except Exception as e:
        return False, "NATIVE RUN FAIL: %s" % str(e)[:300]
    g, w = (got, want)
    if norm:
        g, w = _norm(got), _norm(want)
    if g.strip() != w.strip():
        import difflib
        d = list(difflib.unified_diff(w.split("\n"), g.split("\n"), lineterm=""))[:12]
        return False, "MISMATCH\n" + "\n".join(d)
    return True, "OK (%d lines)" % len(got.split("\n"))


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("src")
    ap.add_argument("-o", "--out", default=None)
    ap.add_argument("--seed", type=int, default=None)
    ap.add_argument("--spread", type=int, default=5)
    ap.add_argument("--dead", type=float, default=0.12)
    ap.add_argument("--runnable", action="store_true")
    ap.add_argument("--banner", default=None)
    ap.add_argument("--width", type=int, default=3000)
    ap.add_argument("--check", action="store_true")
    a = ap.parse_args()
    src = open(a.src, encoding="utf-8").read()
    if a.check:
        ok, msg = check(src, seed=a.seed, spread=a.spread, dead=a.dead)
        print("CHECK:", "PASS" if ok else "FAIL", msg)
    tpl, data = build(src, seed=a.seed, spread=a.spread, dead=a.dead)
    out = finalize(tpl, data, banner=a.banner, width=a.width, runnable=a.runnable)
    dst = a.out or (a.src.replace(".lua", "") + "_oinxer.lua")
    open(dst, "w", encoding="utf-8").write(out)
    print("WROTE", dst, len(out), "bytes")
